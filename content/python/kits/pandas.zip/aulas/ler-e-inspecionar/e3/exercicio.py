from pathlib import Path

base = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()

import pandas as pd

caminho = base / "dados" / "viagens.csv"
# Defina os tipos e as unidades e então leia o arquivo.
