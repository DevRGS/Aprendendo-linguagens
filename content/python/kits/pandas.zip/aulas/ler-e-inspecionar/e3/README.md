# E3 · Resolva

Inventarie as linhas, colunas, tipos e unidades do arquivo. O cabeçalho indica quilômetros e minutos. Leia também sem_viagens.csv para verificar o caso de um arquivo só com o cabeçalho.

Saída esperada

```text
Linhas e colunas: (2, 3)
id string identificador
km float64 km
minutos int64 min
```
