# E2 · Altere ou depure

Retire o argumento dtype e compare o valor e o tipo inferidos.

Saída esperada

```text
[1, 2]
int64
```
