from pathlib import Path

base = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()

import pandas as pd

caminho = base / "dados" / "viagens.csv"

viagens = pd.read_csv(caminho, dtype={"id": "string"})
print(viagens["id"].tolist())
linha = viagens.head(1).iloc[0]
print([linha["id"], float(linha["km"]), int(linha["minutos"])])
