# E1 · Preveja e execute

Leia o arquivo com o ID como texto para preservar os zeros. Mostre os IDs e a primeira linha.

Saída esperada

```text
['001', '002']
['001', 2.5, 7]
```
