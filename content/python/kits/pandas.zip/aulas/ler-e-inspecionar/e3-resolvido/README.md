# Solução comentada

Os tipos foram declarados e as unidades vêm do contrato. O cabeçalho preserva as colunas mesmo sem observações. A seguir, use rótulos para selecionar dados.

Saída esperada

```text
Linhas e colunas: (2, 3)
id string identificador
km float64 km
minutos int64 min
```
