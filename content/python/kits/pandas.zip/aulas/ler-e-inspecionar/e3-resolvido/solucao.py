from pathlib import Path

base = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()

import pandas as pd

caminho = base / "dados" / "viagens.csv"

def ler(caminho):
    tipos = {"id": "string", "km": "float64", "minutos": "int64"}
    return pd.read_csv(caminho, dtype=tipos)

viagens = ler(caminho)
unidades = {"id": "identificador", "km": "km", "minutos": "min"}
print("Linhas e colunas:", viagens.shape)
for coluna, tipo in viagens.dtypes.items():
    print(coluna, tipo, unidades[coluna])
assert ler(caminho.with_name("sem_viagens.csv")).shape == (0, 3)
