# Solução comentada

O zero em A é uma observação. A média de C não é definida, pois o denominador é zero. Em seguida, use a chave de estação para adicionar um nome legível.

Saída esperada

```text
A 1 1 0.0
B 2 2 4.0
C 1 0 ausente
```
