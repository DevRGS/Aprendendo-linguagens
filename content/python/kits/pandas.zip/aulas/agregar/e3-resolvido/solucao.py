import pandas as pd

df = pd.DataFrame({"estacao": ["B", "A", "B", "C"], "minutos": [3, 0, 5, None]})
tabela = df.groupby("estacao", sort=True)["minutos"].agg(
    linhas="size", presentes="count", media="mean"
)
for chave, linha in tabela.iterrows():
    media = "ausente" if pd.isna(linha["media"]) else f"{linha['media']:.1f}"
    print(chave, int(linha["linhas"]), int(linha["presentes"]), media)
assert pd.isna(tabela.loc["C", "media"])
