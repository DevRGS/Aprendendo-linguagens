# E1 · Preveja e execute

Agrupe A:2, A:4 e B:3. Calcule as médias à mão e depois confira.

Saída esperada

```text
{'A': 3.0, 'B': 3.0}
```
