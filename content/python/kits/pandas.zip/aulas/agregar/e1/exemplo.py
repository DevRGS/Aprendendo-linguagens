import pandas as pd

df = pd.DataFrame({"estacao": ["A", "A", "B"], "minutos": [2, 4, 3]})
print(df.groupby("estacao")["minutos"].mean().to_dict())
