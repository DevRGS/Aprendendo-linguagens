import pandas as pd

df = pd.DataFrame({"estacao": ["A", "A", "B", "A"], "minutos": [2, 4, 3, None]})
grupo = df.groupby("estacao")["minutos"]
print(grupo.size().to_dict())
print(grupo.count().to_dict())
