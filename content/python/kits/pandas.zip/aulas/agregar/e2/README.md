# E2 · Altere ou depure

Inclua um tempo ausente em A. Compare os resultados de size e count.

Saída esperada

```text
{'A': 3, 'B': 1}
{'A': 2, 'B': 1}
```
