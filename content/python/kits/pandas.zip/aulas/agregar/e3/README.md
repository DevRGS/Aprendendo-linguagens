# E3 · Resolva

Para B, A, B e C com tempos 3, 0, 5 e ausente, mostre linhas, presentes e média, em ordem de estação. Verifique C, sem tempos presentes.

Saída esperada

```text
A 1 1 0.0
B 2 2 4.0
C 1 0 ausente
```
