import pandas as pd

df = pd.DataFrame({"estacao": ["B", "A", "B", "C"], "minutos": [3, 0, 5, None]})
# Agrupe por estacao e faça o resumo de minutos.
