# Solução comentada

A viagem v2 continua na junção à esquerda. Com cadastro vazio, todas as viagens ficam sem par. Em seguida, leve essa contagem à auditoria.

Saída esperada

```text
IDs: ['v1', 'v2', 'v3']
Sem par: ['v2']
Linhas com inner: 2
```
