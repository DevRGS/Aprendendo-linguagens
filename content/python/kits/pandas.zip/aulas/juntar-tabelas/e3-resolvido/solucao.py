import pandas as pd

def enriquecer(viagens, estacoes):
    return viagens.merge(estacoes, on="estacao", how="left",
                          validate="many_to_one", indicator=True)

viagens = pd.DataFrame({"id": ["v1", "v2", "v3"], "estacao": ["A", "C", "B"]})
estacoes = pd.DataFrame({"estacao": ["A", "B"], "nome": ["Centro", "Norte"]})
uniao = enriquecer(viagens, estacoes)
sem_par = uniao.loc[uniao["_merge"] == "left_only", "id"]
print("IDs:", uniao["id"].tolist())
print("Sem par:", sem_par.tolist())
print("Linhas com inner:", len(viagens.merge(estacoes, on="estacao", how="inner")))
assert enriquecer(viagens, estacoes.iloc[:0])["_merge"].eq("left_only").all()
