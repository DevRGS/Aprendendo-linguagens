import pandas as pd

viagens = pd.DataFrame({"id": ["v1", "v2"], "estacao": ["A", "A"]})
estacoes = pd.DataFrame({"estacao": ["A", "B"], "nome": ["Centro", "Norte"]})
uniao = viagens.merge(estacoes, on="estacao", how="left", validate="many_to_one")
print(uniao[["id", "nome"]].values.tolist())
