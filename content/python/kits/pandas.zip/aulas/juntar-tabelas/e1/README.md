# E1 · Preveja e execute

Combine duas viagens com o cadastro e confira que os IDs de viagem continuam na saída.

Saída esperada

```text
[['v1', 'Centro'], ['v2', 'Centro']]
```
