# E3 · Resolva

Enriqueça três viagens e liste os IDs sem cadastro. Compare com inner e confira o caso de um cadastro vazio com as mesmas colunas.

Saída esperada

```text
IDs: ['v1', 'v2', 'v3']
Sem par: ['v2']
Linhas com inner: 2
```
