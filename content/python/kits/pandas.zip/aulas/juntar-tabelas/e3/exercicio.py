import pandas as pd

viagens = pd.DataFrame({"id": ["v1", "v2", "v3"], "estacao": ["A", "C", "B"]})
estacoes = pd.DataFrame({"estacao": ["A", "B"], "nome": ["Centro", "Norte"]})
# Faça a junção e liste os IDs sem par.
