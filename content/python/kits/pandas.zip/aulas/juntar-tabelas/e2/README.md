# E2 · Altere ou depure

Crie duas linhas com chave A no cadastro. Compare a junção simples com o erro intencional usando a validação many_to_one.

Saída esperada

```text
Linhas sem validação: 3
MergeError: chave duplicada no cadastro
```
