import pandas as pd

viagens = pd.DataFrame({"id": ["v1", "v2"], "estacao": ["A", "B"]})
estacoes = pd.DataFrame({"estacao": ["A", "A", "B"], "nome": ["Centro", "Sul", "Norte"]})
print("Linhas sem validação:", len(viagens.merge(estacoes, on="estacao", how="left")))
try:
    viagens.merge(estacoes, on="estacao", how="left", validate="many_to_one")
except pd.errors.MergeError:
    print("MergeError: chave duplicada no cadastro")
