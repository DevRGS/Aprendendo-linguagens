import pandas as pd

original = pd.DataFrame({"km": [5, 0, 2], "minutos": [15, 3, 8]})
taxas = original.copy()
distancias = taxas["km"].where(taxas["km"] != 0)
taxas["min_por_km"] = taxas["minutos"] / distancias
print(taxas["min_por_km"].dropna().tolist())
print("Índice da taxa ausente:", taxas.index[taxas["min_por_km"].isna()].tolist())
assert original.columns.tolist() == ["km", "minutos"]
assert pd.isna(taxas.loc[1, "min_por_km"])
