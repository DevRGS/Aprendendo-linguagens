# Solução comentada

A unidade é min/km. where conserva valores com condição verdadeira e marca os demais como ausentes. A distância permanece zero e somente a taxa fica ausente. A seguir, veja como ausentes afetam resumos.

Saída esperada

```text
[3.0, 4.0]
Índice da taxa ausente: [1]
```
