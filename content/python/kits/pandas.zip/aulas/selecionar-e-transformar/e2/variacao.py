import pandas as pd

viagens = pd.DataFrame({"id": ["a", "b", "c"], "km": [4, 5, 9]}, index=[10, 30, 50])
print(viagens.loc[30, "id"], viagens.iloc[1, 0])
try:
    viagens.loc[1]
except KeyError:
    print("KeyError: rótulo 1 ausente")
