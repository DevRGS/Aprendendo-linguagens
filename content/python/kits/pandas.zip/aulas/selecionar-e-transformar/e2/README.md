# E2 · Altere ou depure

Use índices 10, 30 e 50. Ache a segunda linha pelo rótulo e pela posição. Compare com a tentativa intencionalmente errada de usar loc[1].

Saída esperada

```text
b b
KeyError: rótulo 1 ausente
```
