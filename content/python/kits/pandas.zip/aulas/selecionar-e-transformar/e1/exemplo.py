import pandas as pd

viagens = pd.DataFrame({"id": ["a", "b", "c"], "km": [4, 5, 9]})
mascara = viagens["km"] >= 5
print(viagens.loc[mascara, "id"].tolist())
