# E1 · Preveja e execute

Quais viagens têm pelo menos 5 km? Faça uma máscara e selecione os IDs com loc.

Saída esperada

```text
['b', 'c']
```
