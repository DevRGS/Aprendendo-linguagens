import pandas as pd

original = pd.DataFrame({"km": [5, 0, 2], "minutos": [15, 3, 8]})
taxas = original.copy()
# Prepare os denominadores e faça a divisão.
