# E3 · Resolva

Acrescente a coluna min_por_km em uma cópia. No caso de 0 km, a taxa deve ficar ausente. Confira que a tabela original segue com as duas colunas iniciais.

Saída esperada

```text
[3.0, 4.0]
Índice da taxa ausente: [1]
```
