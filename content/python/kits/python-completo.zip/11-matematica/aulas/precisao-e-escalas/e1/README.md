# E1 · Preveja e execute

Compare 0.1+0.2 com 0.3 por igualdade e tolerância.

Saída esperada

```text
False
True
```
