from math import isclose
def escalar(valores):
    minimo, maximo = min(valores), max(valores)
    amplitude = maximo - minimo
    if amplitude == 0:
        return [0.0 for _ in valores]
    return [(x - minimo) / amplitude for x in valores]

normal = escalar([2,4,8])
print([round(x, 3) for x in normal])
assert isclose(normal[1], 1/3, abs_tol=1e-9)
print(escalar([5,5]))
