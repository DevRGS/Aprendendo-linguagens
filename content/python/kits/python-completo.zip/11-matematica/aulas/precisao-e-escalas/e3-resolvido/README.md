# Solução comentada

O intervalo original vale 6. Para entrada constante, combinar a regra dos zeros antes de dividir. A função pressupõe ao menos um valor.

Saída esperada

```text
[0.0, 0.333, 1.0]
[0.0, 0.0]
```
