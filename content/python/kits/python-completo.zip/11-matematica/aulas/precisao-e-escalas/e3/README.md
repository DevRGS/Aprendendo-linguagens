# E3 · Resolva

Normalize [2,4,8] pela amplitude. Comprove, por tolerância, o valor intermediário. Use zero para coluna constante.

Saída esperada

```text
[0.0, 0.333, 1.0]
[0.0, 0.0]
```
