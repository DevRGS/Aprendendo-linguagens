valores = [2, 4, 8]
# Implemente escalar e teste [5, 5] também.
