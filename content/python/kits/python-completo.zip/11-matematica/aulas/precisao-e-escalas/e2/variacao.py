from statistics import mean
valores = [2,4,6]
centro = mean(valores)
centrados = [x-centro for x in valores]
print(centrados)
print(mean(centrados))
