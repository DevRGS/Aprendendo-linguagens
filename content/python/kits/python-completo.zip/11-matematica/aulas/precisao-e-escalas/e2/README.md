# E2 · Altere ou depure

Centralize [2,4,6] e confira a média dos resultados.

Saída esperada

```text
[-2, 0, 2]
0
```
