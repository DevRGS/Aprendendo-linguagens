# E2 · Altere ou depure

Acrescente 100 e compare os dois centros.

Saída esperada

```text
28 5.0
```
