from statistics import mean, median
valores = [2,4,6,100]
print(mean(valores), median(valores))
