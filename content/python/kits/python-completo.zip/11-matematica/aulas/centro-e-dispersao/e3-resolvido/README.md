# Solução comentada

Os desvios ao quadrado são 4, 0 e 4. A raiz de 8/2 é 2. Em uma amostra unitária n−1 seria zero.

Saída esperada

```text
2.0
1.633
amostra requer dois valores
```
