from statistics import StatisticsError, pstdev, stdev
print(stdev([2,4,6]))
print(round(pstdev([2,4,6]), 3))
try:
    stdev([2])
except StatisticsError:
    print("amostra requer dois valores")
