from statistics import stdev
valores = [2, 4, 6]
# Informe o desvio e experimente uma única leitura.
