# E3 · Resolva

Calcule o desvio padrão amostral de [2,4,6] e teste uma única leitura.

Saída esperada

```text
2.0
1.633
amostra requer dois valores
```
