from statistics import mean, median
valores = [2,4,6]
print(mean(valores), median(valores), max(valores)-min(valores))
