# E1 · Preveja e execute

Calcule média, mediana e amplitude de [2,4,6].

Saída esperada

```text
4 4 4
```
