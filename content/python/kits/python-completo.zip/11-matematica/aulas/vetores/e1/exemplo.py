x, y = [1, 2], [3, 4]
produtos = [a * b for a, b in zip(x, y, strict=True)]
print(produtos)
print(sum(produtos))
