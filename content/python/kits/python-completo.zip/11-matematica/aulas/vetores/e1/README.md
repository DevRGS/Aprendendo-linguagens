# E1 · Preveja e execute

Calcule os produtos antes de executar e compare o total.

Saída esperada

```text
[3, 8]
11
```
