# Solução comentada

Os produtos são 1 e 6. Em uma média ponderada os pesos somam 1. O modo estrito também protege o caso de tamanhos diferentes.

Saída esperada

```text
7.0
tamanhos diferentes
```
