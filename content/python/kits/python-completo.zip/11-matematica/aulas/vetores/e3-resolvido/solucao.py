def ponderar(pesos, valores):
    return sum(peso * valor for peso, valor in zip(pesos, valores, strict=True))

print(ponderar([0.25, 0.75], [4, 8]))
assert ponderar([1], [12]) == 12
try:
    ponderar([1], [2, 3])
except ValueError:
    print("tamanhos diferentes")
