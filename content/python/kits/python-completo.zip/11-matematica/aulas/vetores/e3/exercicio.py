pesos = [0.25, 0.75]
valores = [4, 8]
# Complete a soma dos produtos e confira os tamanhos.
