# E3 · Resolva

Combine pesos 0.25, 0.75 com os valores 4, 8. Depois faça o mesmo com um elemento e com comprimentos distintos.

Saída esperada

```text
7.0
tamanhos diferentes
```
