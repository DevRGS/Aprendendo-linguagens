# E2 · Altere ou depure

Inspecione os comprimentos. Como impedir que o terceiro valor desapareça?

Saída esperada

```text
2 3
dimensões incompatíveis
```
