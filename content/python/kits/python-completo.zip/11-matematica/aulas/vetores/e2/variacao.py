x, y = [1, 2], [3, 4, 5]
print(len(x), len(y))
try:
    list(zip(x, y, strict=True))
except ValueError:
    print("dimensões incompatíveis")
