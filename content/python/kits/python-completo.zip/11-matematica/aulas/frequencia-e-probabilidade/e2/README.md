# E2 · Altere ou depure

Conte um acerto no grupo A. Compare a frequência no grupo e a frequência conjunta.

Saída esperada

```text
0.5 0.25
```
