registros = [("A", True), ("A", False), ("B", True), ("B", False)]
grupo_a = [acerto for grupo, acerto in registros if grupo == "A"]
print(sum(grupo_a) / len(grupo_a), sum(grupo_a) / len(registros))
