grupos = ["A", "A", "B", "B"]
print(grupos.count("A"), len(grupos))
print(grupos.count("A") / len(grupos))
