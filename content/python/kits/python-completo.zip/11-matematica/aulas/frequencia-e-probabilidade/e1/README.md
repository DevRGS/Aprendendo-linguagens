# E1 · Preveja e execute

Meça a proporção de A em [A, A, B, B].

Saída esperada

```text
2 4
0.5
```
