# Solução comentada

O modelo atribui probabilidade 0.5 ao evento gerado. A frequência da amostra pode variar. O caso vazio é rejeitado antes da divisão.

Saída esperada

```text
observado=0.45 esperado=0.50
n deve ser positivo
```
