from random import Random
def proporcao(seed, n):
    if n <= 0:
        raise ValueError("n deve ser positivo")
    rng = Random(seed)
    return sum(rng.random() < 0.5 for _ in range(n)) / n

observado = proporcao(3, 20)
print(f"observado={observado:.2f} esperado=0.50")
assert proporcao(3, 20) == observado
try:
    proporcao(3, 0)
except ValueError as erro:
    print(erro)
