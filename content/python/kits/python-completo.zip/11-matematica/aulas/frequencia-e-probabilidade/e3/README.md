# E3 · Resolva

Simule 20 lançamentos equiprováveis. Compare com 0.5 e verifique que a mesma semente reproduz a frequência.

Saída esperada

```text
observado=0.45 esperado=0.50
n deve ser positivo
```
