from random import Random
rng = Random(3)
# Faça 20 sorteios e calcule a frequência.
