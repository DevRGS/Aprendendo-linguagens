# E2 · Altere ou depure

Preveja quantos pares saem de duas listas com 2 e 1 itens. Mostre o resultado do zip comum e confira se os comprimentos coincidem.

Saída esperada

```text
[('a', 3)]
False
```
