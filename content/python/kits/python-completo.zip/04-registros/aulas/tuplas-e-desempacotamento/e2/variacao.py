nomes = ["a", "b"]
medidas = [3]
print(list(zip(nomes, medidas)))
print(len(nomes) == len(medidas))
