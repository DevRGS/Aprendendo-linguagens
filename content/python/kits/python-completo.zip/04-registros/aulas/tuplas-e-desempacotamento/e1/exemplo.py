registro = ("a", 3)
identificador, valor = registro
print(identificador, valor)
