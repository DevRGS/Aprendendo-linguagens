# E1 · Preveja e execute

Indique a posição de cada campo e desempacote `("a", 3)` em dois nomes.

Saída esperada

```text
a 3
```
