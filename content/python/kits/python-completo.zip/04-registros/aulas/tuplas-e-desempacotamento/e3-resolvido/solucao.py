nomes = ["A", "B", "C"]
medidas = [2, 3, 4]

if len(nomes) != len(medidas):
    print("Tamanhos incompatíveis")
else:
    for nome, medida in zip(nomes, medidas):
        print(nome, medida)
