# Solução comentada

Comparar os tamanhos antes da iteração impede que parte do lote seja mostrada. Com duas medidas, só sai a mensagem de incompatibilidade. Duas listas vazias têm tamanhos compatíveis e produzem zero pares.

Saída esperada

```text
A 2
B 3
C 4
```
