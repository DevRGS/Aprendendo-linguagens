# E3 · Resolva

Combine os nomes A, B e C com as medidas 2, 3 e 4, na mesma ordem. Exiba cada par. Se o tamanho divergir, rejeite o lote com `Tamanhos incompatíveis`, sem imprimir pares parciais. Teste com a última medida removida.

Saída esperada

```text
A 2
B 3
C 4
```
