nomes = ["A", "B", "C"]
medidas = [2, 3, 4]
# Valide os tamanhos e só então mostre os pares.
