registros = [("A", 2), ("B", 3), ("A", 4)]
por_tema = {}
for tema, minutos in registros:
    por_tema[tema] = por_tema.get(tema, 0) + minutos
    print(tema, por_tema[tema])
