# E1 · Preveja e execute

Preveja o subtotal de A depois de cada passagem. Some os minutos por tema nos pares (A, 2), (B, 3) e (A, 4).

Saída esperada

```text
A 2
B 3
A 6
```
