registros = [("A", 2), ("B", 3), ("A", 4)]
por_tema = {}
total = 0
# Acumule, ordene a apresentação e compare subtotais com o total.
