# E3 · Resolva

Gere um relatório de minutos dos registros (A, 2), (B, 3) e (A, 4). Mostre `A=6`, `B=3` e `total=9`, um por linha e na ordem mostrada. Explique também a saída esperada para um lote vazio.

Saída esperada

```text
A=6
B=3
total=9
```
