# E2 · Altere ou depure

Acrescente (A, 0). Antes de rodar, diga quais resultados mudam entre soma e contagem.

Saída esperada

```text
Registros: 4
Minutos: 9
```
