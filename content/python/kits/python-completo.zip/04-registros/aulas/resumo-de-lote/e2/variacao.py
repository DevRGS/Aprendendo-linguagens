registros = [("A", 2), ("B", 3), ("A", 4), ("A", 0)]
quantidade = 0
total = 0
for tema, minutos in registros:
    quantidade = quantidade + 1
    total = total + minutos
print("Registros:", quantidade)
print("Minutos:", total)
