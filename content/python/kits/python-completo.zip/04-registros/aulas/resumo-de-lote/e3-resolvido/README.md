# Solução comentada

O mapa acumula por tema, sorted garante a ordem e a soma direta fornece o total. Confira que 6 + 3 dá 9. No lote vazio nenhum tema aparece e a saída contém apenas total=0.

Saída esperada

```text
A=6
B=3
total=9
```
