registros = [("A", 2), ("B", 3), ("A", 4)]
por_tema = {}
total = 0
for tema, minutos in registros:
    por_tema[tema] = por_tema.get(tema, 0) + minutos
    total = total + minutos

for tema in sorted(por_tema):
    print(f"{tema}={por_tema[tema]}")
print(f"total={total}")
