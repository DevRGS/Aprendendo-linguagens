lote_a = [8, 2, 8, 4]
lote_b = [4, 2, 6]
comuns = set(lote_a) & set(lote_b)
print(sorted(comuns))
