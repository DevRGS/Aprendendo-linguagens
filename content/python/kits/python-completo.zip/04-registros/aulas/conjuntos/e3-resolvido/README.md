# Solução comentada

A interseção exige ocorrência nos dois lotes. Ordenar produz uma lista estável para mostrar. Se nenhum ID coincide, a interseção e a lista de saída ficam vazias.

Saída esperada

```text
[2, 4]
```
