# E2 · Altere ou depure

Preveja como cada construção trata o texto `"ab"`. Mostre as listas ordenadas para comparar.

Saída esperada

```text
['a', 'b']
['ab']
```
