caracteres = set("ab")
textos = {"ab"}
print(sorted(caracteres))
print(sorted(textos))
