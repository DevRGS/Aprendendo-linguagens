# E3 · Resolva

Para os lotes [8, 2, 8, 4] e [4, 2, 6], mostre os IDs comuns em ordem crescente, sem repetição. Teste também um segundo lote que tenha apenas o ID 9.

Saída esperada

```text
[2, 4]
```
