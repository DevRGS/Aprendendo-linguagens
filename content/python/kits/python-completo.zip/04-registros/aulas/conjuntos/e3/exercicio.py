lote_a = [8, 2, 8, 4]
lote_b = [4, 2, 6]
# Encontre os comuns e mostre em ordem crescente.
