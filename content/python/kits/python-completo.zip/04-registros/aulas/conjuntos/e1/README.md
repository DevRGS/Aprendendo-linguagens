# E1 · Preveja e execute

Preveja quantos IDs únicos há em [2, 2, 4]. Mostre a lista ordenada e a quantidade.

Saída esperada

```text
[2, 4]
2
```
