ids = set([2, 2, 4])
print(sorted(ids))
print(len(ids))
