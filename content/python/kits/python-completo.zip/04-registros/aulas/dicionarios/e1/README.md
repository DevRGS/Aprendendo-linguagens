# E1 · Preveja e execute

Preveja o valor de a antes e depois da atualização. Leia e exiba o campo nas duas etapas.

Saída esperada

```text
2
3
```
