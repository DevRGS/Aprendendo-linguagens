medidas = {"a": 2}
print(medidas["a"])
medidas["a"] = 3
print(medidas["a"])
