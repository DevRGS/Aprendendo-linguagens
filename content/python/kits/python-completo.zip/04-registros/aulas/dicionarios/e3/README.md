# E3 · Resolva

Conte as ocorrências de cada cor em [azul, azul, verde]. Imprima uma linha por cor na ordem da primeira aparição. Confira também se uma entrada vazia produz zero associações.

Saída esperada

```text
azul 2
verde 1
```
