cores = ["azul", "azul", "verde"]
frequencias = {}
# Acumule por cor e percorra os pares de frequencias.
