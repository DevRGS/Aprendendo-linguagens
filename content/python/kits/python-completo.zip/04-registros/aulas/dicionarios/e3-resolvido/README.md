# Solução comentada

Cada ocorrência acrescenta 1 à frequência anterior, que começa em 0 para uma chave nova. items percorre na ordem de inserção. Sem ocorrências, o mapa fica vazio e o segundo laço não imprime linhas.

Saída esperada

```text
azul 2
verde 1
```
