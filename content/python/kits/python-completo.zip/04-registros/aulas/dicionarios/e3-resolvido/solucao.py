cores = ["azul", "azul", "verde"]
frequencias = {}
for cor in cores:
    frequencias[cor] = frequencias.get(cor, 0) + 1
for cor, quantidade in frequencias.items():
    print(cor, quantidade)
