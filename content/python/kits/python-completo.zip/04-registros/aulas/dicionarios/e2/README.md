# E2 · Altere ou depure

Preveja as duas saídas quando a chave a tem valor zero e a chave b está ausente. Compare get com a verificação de presença.

Saída esperada

```text
0 True
0 False
```
