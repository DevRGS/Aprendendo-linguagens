medidas = {"a": 0}
print(medidas.get("a", 0), "a" in medidas)
print(medidas.get("b", 0), "b" in medidas)
