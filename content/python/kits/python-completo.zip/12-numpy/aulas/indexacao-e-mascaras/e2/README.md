# E2 · Altere ou depure

Mude o primeiro valor de uma fatia básica para 99. Repita com uma cópia independente e tente mudar para 77.

Saída esperada

```text
[99, 4, 6]
[99, 4, 6] [77, 4]
```
