import numpy as np

a = np.array([2, 4, 6])
fatia = a[:2]
fatia[0] = 99
print(a.tolist())

independente = a[:2].copy()
independente[0] = 77
print(a.tolist(), independente.tolist())
