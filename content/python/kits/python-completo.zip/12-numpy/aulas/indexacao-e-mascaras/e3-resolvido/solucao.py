import numpy as np

def filtrar(ids, viagens, limite):
    mascara = viagens[:, 0] >= limite
    return ids[mascara], viagens[mascara]

ids = np.array(["L", "M", "N"])
viagens = np.array([[5, 14], [2, 8], [6, 15]])
ids_validos, linhas = filtrar(ids, viagens, 5)
print(ids_validos.tolist(), linhas.tolist())

ids_vazios, linhas_vazias = filtrar(ids, viagens, 20)
assert ids_vazios.shape == (0,)
assert linhas_vazias.shape == (0, 2)
