# Solução comentada

O teste inclui 5 km, e a mesma máscara guarda os IDs e as linhas nas mesmas posições. Se nenhuma linha passar, a tabela vazia ainda tem duas colunas. Na próxima aula, experimente operar uma tabela inteira por eixo.

Saída esperada

```text
['L', 'N'] [[5, 14], [6, 15]]
```
