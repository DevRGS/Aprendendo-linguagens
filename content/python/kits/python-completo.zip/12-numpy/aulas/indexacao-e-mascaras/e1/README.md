# E1 · Preveja e execute

Em `[2, -1, 5]`, marque os valores positivos antes de executar. Imprima primeiro a máscara e depois a seleção.

Saída esperada

```text
[True, False, True]
[2, 5]
```
