import numpy as np

valores = np.array([2, -1, 5])
positivos = valores > 0
print(positivos.tolist())
print(valores[positivos].tolist())
