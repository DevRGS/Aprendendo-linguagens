import numpy as np

ids = np.array(["L", "M", "N"])
viagens = np.array([[5, 14], [2, 8], [6, 15]])
limite = 5
# Crie uma máscara e aplique a ids e viagens.
