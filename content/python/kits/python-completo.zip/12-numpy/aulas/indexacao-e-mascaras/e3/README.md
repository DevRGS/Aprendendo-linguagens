# E3 · Resolva

Filtre as viagens com distância de pelo menos 5 km. A primeira coluna é distância e a segunda é tempo. Selecione os IDs da mesma forma. Confira também um limite para o qual nenhuma linha passa.

Saída esperada

```text
['L', 'N'] [[5, 14], [6, 15]]
```
