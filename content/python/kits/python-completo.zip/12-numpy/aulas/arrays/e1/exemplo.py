import numpy as np

medidas = np.array([[1, 2], [3, 4], [5, 6]], dtype=np.int64)
print(medidas.dtype, medidas.ndim, medidas.shape)
print(medidas.tolist())
