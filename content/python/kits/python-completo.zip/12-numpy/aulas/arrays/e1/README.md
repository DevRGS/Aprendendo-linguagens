# E1 · Preveja e execute

Preveja a forma de três linhas de dois números. Crie o array e confira o tipo, o número de dimensões e a forma.

Saída esperada

```text
int64 2 (3, 2)
[[1, 2], [3, 4], [5, 6]]
```
