import numpy as np

def primeira_amostra(lote):
    return lote[0:1, :]

lote = np.array([[4, 9], [8, 13]])
amostra = primeira_amostra(lote)
print(amostra.shape, amostra.tolist())
unica = primeira_amostra(np.array([[2, 7]]))
assert unica.shape == (1, 2)
assert unica.tolist() == [[2, 7]]
