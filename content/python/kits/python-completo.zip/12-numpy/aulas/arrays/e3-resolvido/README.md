# Solução comentada

A fatia `0:1` mantém o eixo das amostras para que o próximo programa ainda possa contar linhas e colunas. Ela funciona em um lote que já tem uma linha. Na próxima aula, observe o que acontece se você modificar uma fatia.

Saída esperada

```text
(1, 2) [[4, 9]]
```
