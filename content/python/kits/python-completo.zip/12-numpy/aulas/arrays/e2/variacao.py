import numpy as np

medidas = np.array([[1, 2], [3, 4], [5, 6]], dtype=np.int64)
vetor = medidas[:, 0]
coluna = medidas[:, 0:1]
print(vetor.shape, vetor.tolist())
print(coluna.shape, coluna.tolist())
