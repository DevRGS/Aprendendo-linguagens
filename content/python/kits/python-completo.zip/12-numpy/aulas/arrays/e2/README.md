# E2 · Altere ou depure

Selecione a primeira coluna com o índice `0` e depois com a fatia `0:1`. Compare valores e formas.

Saída esperada

```text
(3,) [1, 3, 5]
(3, 1) [[1], [3], [5]]
```
