# E3 · Resolva

Se cada linha é uma amostra, devolva a primeira de `[[4, 9], [8, 13]]` com forma `(1, 2)`. Confira o mesmo contrato com um lote de uma única linha.

Saída esperada

```text
(1, 2) [[4, 9]]
```
