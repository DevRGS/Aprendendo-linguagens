import numpy as np

lote = np.array([[4, 9], [8, 13]])
# Selecione uma linha e confira forma e valores.
