# E2 · Altere ou depure

Use três linhas e uma matriz coluna de pesos. Antecipe a forma de `(3, 2) @ (2, 1)` antes de rodar.

Saída esperada

```text
(3, 1) [[4], [10], [16]]
```
