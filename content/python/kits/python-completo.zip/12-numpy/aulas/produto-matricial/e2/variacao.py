import numpy as np

a = np.array([[1, 2], [3, 4], [5, 6]])
pesos = np.array([[2], [1]])
notas = a @ pesos
print(notas.shape, notas.tolist())
