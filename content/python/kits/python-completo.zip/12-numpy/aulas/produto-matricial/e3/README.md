# E3 · Resolva

Obtenha uma pontuação por linha de `[[1, 3], [2, 5], [0, 4]]` com pesos `[0.5, 2.0]`. Faça por laços e por `@`, compare com `np.allclose` e teste lote de uma linha.

Saída esperada

```text
[6.5, 11.0, 8.0]
True
```
