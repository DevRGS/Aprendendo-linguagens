import numpy as np

a = np.array([[1, 3], [2, 5], [0, 4]])
pesos = np.array([0.5, 2.0])
# Calcule a primeira nota à mão antes de escrever os laços.
