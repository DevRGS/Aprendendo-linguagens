# Solução comentada

O laço interno combina cada valor com seu peso e acumula a pontuação. `strict=True` evita truncar silenciosamente uma linha de comprimento incompatível. Para uma linha a saída continua sendo um vetor. Se errou o eixo no marco, volte a [Eixos e broadcasting](#/python/numpy/eixos-e-broadcasting) e repita aqui com pesos [1, 0] e uma linha [7, 2]. A seguir, o pandas acrescenta rótulos e chaves às tabelas.

Saída esperada

```text
[6.5, 11.0, 8.0]
True
```
