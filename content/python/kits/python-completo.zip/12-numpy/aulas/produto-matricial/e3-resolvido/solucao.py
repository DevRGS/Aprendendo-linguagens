import numpy as np

def pontuar_laco(a, pesos):
    notas = []
    for linha in a:
        soma = 0.0
        for valor, peso in zip(linha, pesos, strict=True):
            soma += valor * peso
        notas.append(soma)
    return notas

a = np.array([[1, 3], [2, 5], [0, 4]])
pesos = np.array([0.5, 2.0])
notas = a @ pesos
print(notas.tolist())
print(np.allclose(pontuar_laco(a, pesos), notas))
assert (a[:1] @ pesos).shape == (1,)
assert np.allclose(pontuar_laco(a[:1], pesos), a[:1] @ pesos)
