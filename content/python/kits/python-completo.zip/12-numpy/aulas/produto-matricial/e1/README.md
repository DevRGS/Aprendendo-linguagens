# E1 · Preveja e execute

Preveja a nota da segunda linha antes de usar os pesos `[2, 1]`. Compare o efeito de `*` e `@`.

Saída esperada

```text
[[2, 2], [6, 4]]
[4, 10]
```
