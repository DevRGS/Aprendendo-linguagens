import numpy as np

a = np.array([[1, 2], [3, 4]])
pesos = np.array([2, 1])
print((a * pesos).tolist())
print((a @ pesos).tolist())
