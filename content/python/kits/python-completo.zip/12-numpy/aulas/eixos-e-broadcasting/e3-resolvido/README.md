# Solução comentada

O erro ocorre porque 2 e 3 se encontram na última dimensão. Com `keepdims=True` as médias ficam em (3, 1), uma por linha, e cada média é subtraída das duas colunas da sua linha. Também funciona com uma única linha. Por que uma matriz quadrada pode mascarar o erro ao omitir `keepdims`? Ela alinha as médias ao eixo das colunas sem falhar. A próxima aula usa os mesmos eixos para combinar colunas com pesos.

Saída esperada

```text
(3, 2) (3,)
ValueError: dimensões finais incompatíveis
[[-1.0, 1.0], [-2.0, 2.0], [0.0, 0.0]]
```
