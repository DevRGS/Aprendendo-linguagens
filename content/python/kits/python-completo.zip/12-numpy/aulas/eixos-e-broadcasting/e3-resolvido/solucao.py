import numpy as np

def centrar_linhas(a):
    return a - a.mean(axis=1, keepdims=True)

dados = [[1, 3], [4, 8], [2, 2]]
a = np.array(dados, dtype=float)
medias_linhas = a.mean(axis=1)
print(a.shape, medias_linhas.shape)
try:
    a - medias_linhas
except ValueError:
    print("ValueError: dimensões finais incompatíveis")

centrada = centrar_linhas(a)
print(centrada.tolist())
assert centrada.shape == a.shape
np.testing.assert_allclose(centrada.mean(axis=1), 0, atol=1e-9)
np.testing.assert_allclose(centrar_linhas(np.array([[3, 7]])), [[-2, 2]])
