import numpy as np

dados = [[1, 3], [4, 8], [2, 2]]
a = np.array(dados, dtype=float)
# Calcule as médias das linhas preservando a dimensão reduzida.
