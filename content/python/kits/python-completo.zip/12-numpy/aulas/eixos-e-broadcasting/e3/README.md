# E3 · Resolva

Centre as **linhas** de `[[1, 3], [4, 8], [2, 2]]`. Preveja as formas de `a` e de `a.mean(axis=1)`. Reproduza a subtração direta como erro intencional e corrija para preservar a forma. Verifique também uma única linha.

Saída esperada

```text
(3, 2) (3,)
ValueError: dimensões finais incompatíveis
[[-1.0, 1.0], [-2.0, 2.0], [0.0, 0.0]]
```
