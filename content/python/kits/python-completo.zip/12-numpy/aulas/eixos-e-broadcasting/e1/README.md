# E1 · Preveja e execute

Escreva os dois pares que entram nas médias. Calcule uma média por coluna.

Saída esperada

```text
(2,) [2.0, 3.0]
```
