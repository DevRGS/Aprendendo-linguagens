import numpy as np

a = np.array([[1, 2], [3, 4]])
medias = a.mean(axis=0)
print(medias.shape, medias.tolist())
