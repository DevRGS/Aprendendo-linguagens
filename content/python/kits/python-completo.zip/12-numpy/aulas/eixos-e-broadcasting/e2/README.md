# E2 · Altere ou depure

Subtraia o vetor de médias das linhas. Verifique que as médias por coluna chegam a zero.

Saída esperada

```text
[[-1.0, -1.0], [1.0, 1.0]]
[0.0, 0.0]
```
