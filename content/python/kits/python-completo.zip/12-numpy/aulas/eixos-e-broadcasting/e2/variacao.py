import numpy as np

a = np.array([[1, 2], [3, 4]])
centrada = a - a.mean(axis=0)
print(centrada.tolist())
print(centrada.mean(axis=0).tolist())
