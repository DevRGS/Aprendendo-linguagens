def media(valores: list[float]) -> float:
    """Calcule a média de uma lista não vazia."""
    return sum(valores) / len(valores)

print(media([2.0, 4.0]))
