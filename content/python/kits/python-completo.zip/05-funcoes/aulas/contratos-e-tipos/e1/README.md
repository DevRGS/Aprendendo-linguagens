# E1 · Preveja e execute

A função abaixo espera uma lista numérica não vazia. Preveja a soma, a quantidade e o retorno para [2.0, 4.0].

Saída esperada

```text
3.0
```
