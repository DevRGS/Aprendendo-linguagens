# Solução comentada

A função verifica o limite antes da divisão. Uma lista de dois zeros produz 0.0 e não passa pelo ramo da ausência. As anotações descrevem os tipos previstos e o teste de comprimento faz a decisão real.

Saída esperada

```text
3.0
None
```
