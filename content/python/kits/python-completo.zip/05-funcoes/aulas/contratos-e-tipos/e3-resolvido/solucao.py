def media_ou_none(valores: list[float]) -> float | None:
    """Retorne a média dos números ou None quando a lista estiver vazia."""
    if len(valores) == 0:
        return None
    return sum(valores) / len(valores)

print(media_ou_none([2, 4]))
print(media_ou_none([]))
