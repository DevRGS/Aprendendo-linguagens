def media_ou_none(valores: list[float]) -> float | None:
    # Documente o contrato antes de escrever as instruções do corpo.
    pass

print(media_ou_none([2, 4]))
print(media_ou_none([]))
