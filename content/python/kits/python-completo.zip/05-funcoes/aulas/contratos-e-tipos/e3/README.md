# E3 · Resolva

Implemente `media_ou_none` com anotação e docstring. Para uma lista de números não vazia, devolva a média como float. Para uma vazia, devolva None. Mostre o resultado de [2, 4] e []. Confira o caso [0, 0] para distinguir zero de ausência.

Saída esperada

```text
3.0
None
```
