# E2 · Altere ou depure

Faça a chamada intencionalmente fora do contrato com lista vazia. Preveja se a anotação bloqueia a entrada antes de o corpo rodar. O exemplo captura só o erro esperado.

Saída esperada

```text
ZeroDivisionError
```
