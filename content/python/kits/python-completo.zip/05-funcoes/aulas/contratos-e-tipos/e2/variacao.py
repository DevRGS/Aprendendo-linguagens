def media(valores: list[float]) -> float:
    """Calcule a média de uma lista não vazia."""
    return sum(valores) / len(valores)

try:
    media([])
except ZeroDivisionError:
    print("ZeroDivisionError")
