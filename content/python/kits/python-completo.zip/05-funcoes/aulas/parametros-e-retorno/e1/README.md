# E1 · Preveja e execute

Preveja o retorno de dobro(3) e o resultado ao acrescentar 1. Mostre os dois.

Saída esperada

```text
6
7
```
