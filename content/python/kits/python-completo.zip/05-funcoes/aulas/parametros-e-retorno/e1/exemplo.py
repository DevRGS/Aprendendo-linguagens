def dobro(numero):
    return numero * 2

resultado = dobro(3)
print(resultado)
print(resultado + 1)
