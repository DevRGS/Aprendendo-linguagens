# E3 · Resolva

Escreva `minutos(h, m)` para receber horas inteiras não negativas e minutos inteiros entre 0 e 59. A função deve devolver o total em minutos e a chamada deve exibir o resultado de (2, 15). Confira que (0, 0) retorna 0.

Saída esperada

```text
135
```
