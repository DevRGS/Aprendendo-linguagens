def minutos(h, m):
    pass  # Devolva o total de minutos.

# Mostre o valor devolvido para 2 horas e 15 minutos.
