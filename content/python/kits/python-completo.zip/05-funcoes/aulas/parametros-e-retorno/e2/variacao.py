def mostrar_dobro(numero):
    print(numero * 2)

valor = mostrar_dobro(3)
print(valor)

def dobro(numero):
    return numero * 2

valor = dobro(3)
print(valor + 1)
