# E2 · Altere ou depure

A primeira função apenas imprime. Preveja o que será escrito pela função e o que será escrito após guardar seu retorno. Compare com uma versão que devolve o valor.

Saída esperada

```text
6
None
7
```
