# Solução comentada

Cada hora vale 60 minutos. Multiplique h por 60, some m e retorne esse inteiro. Deixe print no chamador para manter a função reutilizável. A entrada (0, 0) respeita a faixa e devolve zero.

Saída esperada

```text
135
```
