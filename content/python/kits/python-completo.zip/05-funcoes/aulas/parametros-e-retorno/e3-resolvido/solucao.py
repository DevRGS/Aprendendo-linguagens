def minutos(h, m):
    return h * 60 + m

print(minutos(2, 15))
