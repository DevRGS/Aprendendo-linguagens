# E1 · Preveja e execute

Preveja o retorno da limpeza e a etiqueta final para um nome com espaços. Execute a composição e exiba a etiqueta.

Saída esperada

```text
Nome: Lia
```
