def limpar_nome(texto):
    return texto.strip()

def gerar_etiqueta(nome):
    return f"Nome: {nome}"

print(gerar_etiqueta(limpar_nome(" Lia ")))
