# Solução comentada

normalizar tira espaços e converte os nomes em minúsculas. somar_por_tema reúne nomes iguais. apresentar usa a ordem de sorted, que compara textos por pontos de código. Assim, luz precede água. Os dois testes isolam a limpeza para som e a soma 3 para luz. Com lote vazio, não há temas e sum dos subtotais devolve 0.

Saída esperada

```text
luz: 3 min
água: 6 min
Total: 9 min
```
