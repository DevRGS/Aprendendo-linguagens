def normalizar(registros):
    return [(tema.strip().lower(), minutos) for tema, minutos in registros]

def somar_por_tema(registros):
    totais = {}
    for tema, minutos in registros:
        totais[tema] = totais.get(tema, 0) + minutos
    return totais

def apresentar(totais):
    for tema in sorted(totais):
        print(f"{tema}: {totais[tema]} min")
    print(f"Total: {sum(totais.values())} min")

registros = [(" Água ", 2), ("água", 4), ("LUZ", 3)]
apresentar(somar_por_tema(normalizar(registros)))
