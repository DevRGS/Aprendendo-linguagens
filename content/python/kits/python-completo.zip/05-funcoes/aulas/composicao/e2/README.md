# E2 · Altere ou depure

Compare a ordem inicial com a ordem esperada por duração crescente. Forneça uma função key que leia a duração de cada registro.

Saída esperada

```text
[('Luz', 3), ('Som', 4), ('Água', 6)]
```
