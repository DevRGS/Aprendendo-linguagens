def duracao(registro):
    tema, minutos = registro
    return minutos

registros = [("Água", 6), ("Luz", 3), ("Som", 4)]
ordenados = sorted(registros, key=duracao)
print(ordenados)
