# E3 · Resolva

Separe a limpeza dos temas, a soma de minutos e a apresentação em funções. Use [(" Água ", 2), ("água", 4), ("LUZ", 3)] e mostre minutos por tema normalizado pela ordem de `sorted`, além do total. Confira cada etapa com entrada própria: a limpeza recebe [(" SOM ", 0)] e a soma recebe [("luz", 2), ("luz", 0), ("luz", 1)]. No lote vazio, mostre apenas total zero.

Saída esperada

```text
luz: 3 min
água: 6 min
Total: 9 min
```
