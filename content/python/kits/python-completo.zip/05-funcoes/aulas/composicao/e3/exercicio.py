registros = [(" Água ", 2), ("água", 4), ("LUZ", 3)]

def normalizar(registros):
    pass

def somar_por_tema(registros):
    pass

def apresentar(totais):
    pass

# Componha as funções passando adiante cada retorno.
