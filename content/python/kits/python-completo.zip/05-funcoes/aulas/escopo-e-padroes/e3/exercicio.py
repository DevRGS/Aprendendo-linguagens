def rotular(texto, prefixo="Item"):
    pass  # Devolva o rótulo.

origem = "Água"
# Experimente as duas formas de chamar e exiba a origem.
