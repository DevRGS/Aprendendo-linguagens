# E3 · Resolva

Crie `rotular(texto, prefixo='Item')` para devolver o rótulo com dois pontos e um espaço entre prefixo e texto. Mostre o padrão e a troca por `Tema` via argumento nomeado para `Água`, depois mostre que a origem permanece `Água`. Teste também texto vazio.

Saída esperada

```text
Item: Água
Tema: Água
Água
```
