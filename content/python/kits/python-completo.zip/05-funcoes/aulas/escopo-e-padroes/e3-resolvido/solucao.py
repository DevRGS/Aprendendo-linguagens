def rotular(texto, prefixo="Item"):
    return f"{prefixo}: {texto}"

origem = "Água"
print(rotular(origem))
print(rotular(origem, prefixo="Tema"))
print(origem)
