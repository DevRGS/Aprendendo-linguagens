# Solução comentada

A f-string cria outro texto. O argumento nomeado muda o prefixo apenas naquela chamada. Para texto vazio, o resultado termina em dois pontos e um espaço, sem caracteres de texto depois.

Saída esperada

```text
Item: Água
Tema: Água
Água
```
