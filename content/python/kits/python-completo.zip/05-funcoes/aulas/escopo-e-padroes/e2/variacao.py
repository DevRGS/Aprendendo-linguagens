def adicionar_partilhado(item, lista=[]):
    lista.append(item)
    return lista

print(adicionar_partilhado("A"))
print(adicionar_partilhado("B"))

def adicionar(item, lista=None):
    if lista is None:
        lista = []
    lista.append(item)
    return lista

print(adicionar("A"))
print(adicionar("B"))
