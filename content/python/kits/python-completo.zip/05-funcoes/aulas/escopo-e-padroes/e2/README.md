# E2 · Altere ou depure

A primeira versão tem uma lista compartilhada como padrão, um erro intencional de estado. Preveja os retornos de duas chamadas seguidas e compare com a versão corrigida.

Saída esperada

```text
['A']
['A', 'B']
['A']
['B']
```
