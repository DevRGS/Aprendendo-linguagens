# E1 · Preveja e execute

Preveja o preço final de 100 sem passar taxa. Chame também com taxa explícita de 25%.

Saída esperada

```text
90.0
75.0
```
