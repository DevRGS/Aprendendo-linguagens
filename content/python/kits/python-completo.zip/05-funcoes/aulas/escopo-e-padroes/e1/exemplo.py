def desconto(preco, taxa=0.10):
    abatimento = preco * taxa
    return preco - abatimento

print(desconto(100))
print(desconto(preco=100, taxa=0.25))
