# E1 · Preveja e execute

Escreva o teste de minutos(1, 5) com esperado 65. Carregue a classe de teste, execute um caso e confira a contagem.

Saída esperada

```text
casos: 1 sucesso: True
```
