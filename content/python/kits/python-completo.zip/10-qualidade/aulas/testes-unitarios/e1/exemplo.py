import io
import unittest

def minutos(horas, restantes):
    return horas * 60 + restantes

class TestesMinutos(unittest.TestCase):
    def test_hora_e_minutos(self):
        self.assertEqual(minutos(1, 5), 65)


suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestesMinutos)
registro = io.StringIO()
resultado = unittest.TextTestRunner(stream=registro).run(suite)

print("casos:", resultado.testsRun, "sucesso:", resultado.wasSuccessful())
