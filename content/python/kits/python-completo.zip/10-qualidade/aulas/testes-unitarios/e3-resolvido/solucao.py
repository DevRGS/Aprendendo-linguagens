import io
import unittest

def minutos(horas, restantes):
    if type(horas) is not int or type(restantes) is not int:
        raise ValueError("horas e minutos devem ser inteiros")
    if horas < 0 or not 0 <= restantes <= 59:
        raise ValueError("horas ou minutos fora do intervalo")
    return horas * 60 + restantes

class TestesMinutos(unittest.TestCase):
    def test_conversao(self):
        self.assertEqual(minutos(1, 5), 65)

    def test_limite_inferior(self):
        self.assertEqual(minutos(0, 0), 0)

    def test_minutos_fora_do_intervalo(self):
        with self.assertRaises(ValueError):
            minutos(0, 60)


suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestesMinutos)
registro = io.StringIO()
resultado = unittest.TextTestRunner(stream=registro).run(suite)

print("casos:", resultado.testsRun, "sucesso:", resultado.wasSuccessful())
