# Solução comentada

Zero horas e zero minutos formam a borda inferior válida. Sessenta minutos restantes violam o contrato. O teste passa quando a chamada levanta a classe esperada. Confira sempre testsRun para detectar a suíte vazia.

Saída esperada

```text
casos: 3 sucesso: True
```
