import io
import unittest

def minutos(horas, restantes):
    # Implemente o contrato de conversão.
    raise NotImplementedError

class TestesMinutos(unittest.TestCase):
    def test_conversao(self):
        self.assertEqual(minutos(1, 5), 65)

    # Escreva os testes de zero e de minutos inválidos.


suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestesMinutos)
registro = io.StringIO()
resultado = unittest.TextTestRunner(stream=registro).run(suite)

print("casos:", resultado.testsRun, "sucesso:", resultado.wasSuccessful())
