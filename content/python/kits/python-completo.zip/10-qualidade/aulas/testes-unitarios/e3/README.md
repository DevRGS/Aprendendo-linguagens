# E3 · Resolva

Crie três testes de minutos(horas, restantes), para (1, 5), (0, 0) e (0, 60). O domínio tem horas inteiras não negativas e minutos restantes entre 0 e 59. Caso inválido deve levantar ValueError, verificado com assertRaises.

Saída esperada

```text
casos: 3 sucesso: True
```
