# E2 · Altere ou depure

Teste intencionalmente uma implementação que ignora os minutos restantes. Use a entrada de borda (0, 1) e veja se a falha é detectada.

Saída esperada

```text
falhas: 1 sucesso: False
```
