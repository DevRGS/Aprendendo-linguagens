import io
import unittest

def minutos(horas, restantes):
    return horas * 60

class TestesMinutos(unittest.TestCase):
    def test_um_minuto(self):
        self.assertEqual(minutos(0, 1), 1)


suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestesMinutos)
registro = io.StringIO()
resultado = unittest.TextTestRunner(stream=registro).run(suite)

print("falhas:", len(resultado.failures), "sucesso:", resultado.wasSuccessful())
