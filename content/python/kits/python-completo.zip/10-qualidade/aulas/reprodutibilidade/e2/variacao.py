from random import Random

a, b = Random(7), Random(7)
primeiro = a.random()
segundo = a.random()
b.random()
deslocado = b.random()
print(primeiro == deslocado)
print(segundo == deslocado)
