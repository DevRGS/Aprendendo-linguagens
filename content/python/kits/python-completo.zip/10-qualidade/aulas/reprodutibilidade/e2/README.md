# E2 · Altere ou depure

Use a mesma semente nos dois geradores, mas faça uma chamada a mais no segundo antes de comparar. Verifique se seu próximo valor coincide com o segundo valor do primeiro gerador.

Saída esperada

```text
False
True
```
