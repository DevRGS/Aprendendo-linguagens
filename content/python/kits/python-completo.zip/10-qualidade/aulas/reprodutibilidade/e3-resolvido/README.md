# Solução comentada

Ordenar estabiliza a saída do conjunto. sort_keys organiza o JSON por chave. O resumo guarda a semente como parâmetro de uma eventual simulação. Nenhum sorteio é feito nesta auditoria. A entrada vazia continua reproduzível, com ambas as contagens em zero.

Saída esperada

```text
['a', 'b'] 3 2
True
[] 0 0
```
