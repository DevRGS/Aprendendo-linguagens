import json
import sys
from pathlib import Path

def resumir(ids, semente):
    unicos = sorted(set(ids))
    return {
        "ids": unicos,
        "quantidade": len(ids),
        "unicos": len(unicos),
        "semente": semente,
        "python": ".".join(map(str, sys.version_info[:3])),
        "origem": "lote fictício da atividade",
    }

entrada = ["b", "a", "b"]
primeiro = resumir(entrada, 7)
caminho = Path("auditoria.json")
caminho.write_text(json.dumps(primeiro, ensure_ascii=False, sort_keys=True),
                   encoding="utf-8")
recuperado = json.loads(caminho.read_text(encoding="utf-8"))
print(recuperado["ids"], recuperado["quantidade"], recuperado["unicos"])
print(recuperado == resumir(entrada, 7))
vazio = resumir([], 7)
print(vazio["ids"], vazio["quantidade"], vazio["unicos"])
