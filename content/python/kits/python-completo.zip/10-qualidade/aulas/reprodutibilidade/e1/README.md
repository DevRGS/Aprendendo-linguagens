# E1 · Preveja e execute

Crie dois objetos Random com a mesma semente e faça três chamadas random em cada um. Compare as sequências.

Saída esperada

```text
True 3
```
