from random import Random

a, b = Random(7), Random(7)
primeira = [a.random() for _ in range(3)]
segunda = [b.random() for _ in range(3)]
print(primeira == segunda, len(primeira))
