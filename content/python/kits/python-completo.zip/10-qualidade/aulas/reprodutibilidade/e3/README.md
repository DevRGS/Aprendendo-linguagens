# E3 · Resolva

Produza `auditoria.json` com IDs únicos ordenados, contagens, semente, versão Python e origem do lote. Para ["b", "a", "b"], faça dois resumos iguais e confirme contagens 3 e 2. Para [] espere 0 IDs e zero contagens.

Saída esperada

```text
['a', 'b'] 3 2
True
[] 0 0
```
