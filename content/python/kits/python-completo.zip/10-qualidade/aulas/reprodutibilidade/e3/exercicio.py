import json
import sys
from pathlib import Path

entrada = ["b", "a", "b"]
semente = 7
# Registre parâmetros e proveniência, grave e releia o resumo.
