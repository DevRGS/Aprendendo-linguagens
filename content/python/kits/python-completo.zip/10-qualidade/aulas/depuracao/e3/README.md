# E3 · Resolva

Corrija o filtro que descarta zero junto com valores ausentes. O contrato considera somente None como ausente. Preserve a ordem, faça [None, 0, 5] virar [0, 5] e [] virar []. Inclua um teste de regressão para o zero.

Saída esperada

```text
[5]
[0, 5]
regressão verificada
```
