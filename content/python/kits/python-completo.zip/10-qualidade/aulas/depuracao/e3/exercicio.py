def sem_ausentes(medidas):
    # Corrija a condição.
    return [n for n in medidas if n]

assert sem_ausentes([None, 0, 5]) == [0, 5]
assert sem_ausentes([]) == []
