registro = {"valor": "7"}
print(sorted(registro))
try:
    print(registro["id"])
except KeyError as erro:
    print(type(erro).__name__, erro.args[0])
