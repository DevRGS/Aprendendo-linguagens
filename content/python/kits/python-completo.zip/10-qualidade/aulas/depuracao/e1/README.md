# E1 · Preveja e execute

Identifique a chave que causa KeyError em um registro contendo apenas valor. Inspecione as chaves antes do acesso.

Saída esperada

```text
['valor']
KeyError id
```
