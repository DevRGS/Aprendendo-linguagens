# Solução comentada

if n trata zero e None como falsos. A comparação de identidade retira apenas None. O teste que exige zero seria reprovado pelo filtro antigo, e o caso com None sozinho confirma a remoção.

Saída esperada

```text
[5]
[0, 5]
regressão verificada
```
