def antes(medidas):
    return [n for n in medidas if n]

def sem_ausentes(medidas):
    return [n for n in medidas if n is not None]

entrada = [None, 0, 5]
print(antes(entrada))
print(sem_ausentes(entrada))
assert sem_ausentes(entrada) == [0, 5]
assert sem_ausentes([]) == []
assert sem_ausentes([None]) == []
print("regressão verificada")
