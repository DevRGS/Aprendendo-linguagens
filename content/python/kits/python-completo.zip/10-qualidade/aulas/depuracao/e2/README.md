# E2 · Altere ou depure

Compare um registro sem valor e outro com valor "sete". Preveja se falham no mesmo ponto.

Saída esperada

```text
a campo ausente
b valor inválido
```
