registros = [{"id": "a"}, {"id": "b", "valor": "sete"}]
for registro in registros:
    try:
        texto = registro["valor"]
        valor = int(texto)
    except KeyError:
        print(registro["id"], "campo ausente")
    except ValueError:
        print(registro["id"], "valor inválido")
