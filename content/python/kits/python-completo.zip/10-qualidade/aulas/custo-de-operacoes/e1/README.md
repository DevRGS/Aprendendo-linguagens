# E1 · Preveja e execute

Conte comparações ao buscar 40 e 99 em [10, 20, 30, 40]. Identifique se uma busca para antes da outra.

Saída esperada

```text
(True, 4)
(False, 4)
```
