def buscar_lista(valores, alvo):
    comparacoes = 0
    for valor in valores:
        comparacoes += 1
        if valor == alvo:
            return True, comparacoes
    return False, comparacoes

ids = [10, 20, 30, 40]
for alvo in [40, 99]:
    print(buscar_lista(ids, alvo))
