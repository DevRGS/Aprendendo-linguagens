# E3 · Resolva

Confirme o acordo entre lista e índice para 100 IDs e 1000 consultas alternadas ao último e a um ausente. Conte comparações da lista, itens da construção e consultas ao índice. Confira a pertinência em entrada vazia e justifique quando reaproveitar o índice.

Saída esperada

```text
respostas iguais: True
comparações: 100000
construção e consultas: 100 1000
vazio: True
```
