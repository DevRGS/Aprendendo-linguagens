ids = list(range(100))
consultas = [99, -1] * 500
# Use a busca contada de E1 e compare os resultados com um set.
# Inclua uma entrada vazia.
