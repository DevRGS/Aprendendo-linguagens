# Solução comentada

São 100 comparações em cada busca de último ou ausente. Construir o índice uma vez favorece muitas consultas repetidas e custa memória para as chaves. Para uma consulta simples em uma lista pequena, a passagem de construção pode não compensar. Uma entrada vazia dá ausência nos dois casos.

Saída esperada

```text
respostas iguais: True
comparações: 100000
construção e consultas: 100 1000
vazio: True
```
