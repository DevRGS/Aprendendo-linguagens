def buscar_lista(valores, alvo):
    comparacoes = 0
    for valor in valores:
        comparacoes += 1
        if valor == alvo:
            return True, comparacoes
    return False, comparacoes

ids = list(range(100))
consultas = [99, -1] * 500
indice = set(ids)
resultados = [buscar_lista(ids, alvo) for alvo in consultas]
iguais = [a for a, _ in resultados] == [alvo in indice for alvo in consultas]
print("respostas iguais:", iguais)
print("comparações:", sum(qtd for _, qtd in resultados))
print("construção e consultas:", len(ids), len(consultas))
print("vazio:", buscar_lista([], 99)[0] == (99 in set()))
