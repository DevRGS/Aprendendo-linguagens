def buscar_lista(valores, alvo):
    comparacoes = 0
    for valor in valores:
        comparacoes += 1
        if valor == alvo:
            return True, comparacoes
    return False, comparacoes

ids = [10, 20, 30, 40]
consultas = [40, 99, 10]

resultados = [buscar_lista(ids, alvo) for alvo in consultas]
indice = set(ids)
respostas = [alvo in indice for alvo in consultas]
print([encontrado for encontrado, _ in resultados] == respostas)
print("comparações na lista:", sum(contagem for _, contagem in resultados))
print("itens lidos para construir:", len(ids))
print("consultas ao índice:", len(consultas))
