# E2 · Altere ou depure

Para quatro IDs e três consultas, compare a busca repetida na lista com a construção de um único set e consultas de pertinência. Confira as mesmas respostas.

Saída esperada

```text
True
comparações na lista: 9
itens lidos para construir: 4
consultas ao índice: 3
```
