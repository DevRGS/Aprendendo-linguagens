primeiro_texto = input()
# Converta o primeiro texto, leia e converta o segundo.
# Mostre a soma.
