# E3 · Resolva

Leia dois inteiros, um por linha, e mostre a soma. Digite `12`, depois `5`. A saída deve ser `17`. Como variação, tente `doze` na primeira leitura. Preveja a classe de erro e se a soma aparece.

Digite cada entrada em uma linha.

```text
12
5
```

Saída esperada

```text
17
```
