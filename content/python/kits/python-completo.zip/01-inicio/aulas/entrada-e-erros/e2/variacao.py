try:
    prin("oi")
except NameError:
    print("NameError")

try:
    compile('print("oi)', "<exemplo>", "exec")
except SyntaxError:
    print("SyntaxError")

print("oi")
