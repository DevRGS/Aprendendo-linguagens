# E2 · Altere ou depure

Compare os exemplos intencionalmente incorretos `prin("oi")` e `print("oi)`. Antes de rodar a demonstração abaixo, classifique qual falha na leitura e qual falha só ao executar. O bloco usa `try` para observar exatamente a classe esperada e seguir com a outra demonstração.

Saída esperada

```text
NameError
SyntaxError
oi
```
