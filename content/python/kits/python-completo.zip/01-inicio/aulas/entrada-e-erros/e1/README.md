# E1 · Preveja e execute

Quando a execução esperar a entrada, digite `12` e confirme com Enter. Transcrição da prática: você digita `12` e o programa escreve `13`. Antes de rodar, diga em que momento surge um inteiro.

Digite cada entrada em uma linha.

```text
12
```

Saída esperada

```text
13
```
