texto = input()
numero = int(texto)
print(numero + 1)
