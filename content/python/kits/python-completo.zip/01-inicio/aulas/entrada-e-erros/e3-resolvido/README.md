# Solução comentada

Cada conversão cria um inteiro antes da adição. Na variação, int('doze') levanta ValueError, a segunda leitura não começa e a soma não aparece. No terminal ou caderno, leia a última linha do erro para confirmar a classe.

Digite cada entrada em uma linha.

```text
12
5
```

Saída esperada

```text
17
```
