primeiro = int(input())
segundo = int(input())
print(primeiro + segundo)
