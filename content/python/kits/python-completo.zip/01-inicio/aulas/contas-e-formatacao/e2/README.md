# E2 · Altere ou depure

Preveja qual expressão calcula a soma primeiro. Execute as duas e confira seus palpites.

Saída esperada

```text
14
20
```
