total_minutos = 135
horas = total_minutos // 60
minutos = total_minutos % 60
print(f"{horas} horas e {minutos} minutos")
