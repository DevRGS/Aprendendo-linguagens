# E1 · Preveja e execute

Preveja o número de horas completas e de minutos restantes. Em seguida, converta 135 minutos e imprima os dois valores em uma frase.

Saída esperada

```text
2 horas e 15 minutos
```
