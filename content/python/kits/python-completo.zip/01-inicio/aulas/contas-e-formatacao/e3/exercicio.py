quantidade = 3
preco = 2.50
# Calcule e exiba o total.
