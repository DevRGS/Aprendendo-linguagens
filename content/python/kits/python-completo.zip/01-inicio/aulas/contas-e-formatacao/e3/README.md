# E3 · Resolva

Calcule o total de 3 itens de 2,50 e exiba `Total: 7.50`. Mostre como caso de borda o total de zero itens e explique onde surgem os zeros à direita.

Saída esperada

```text
Total: 7.50
```
