quantidade = 3
preco = 2.50
total = quantidade * preco
print(f"Total: {total:.2f}")
