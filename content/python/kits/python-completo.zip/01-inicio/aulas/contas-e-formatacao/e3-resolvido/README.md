# Solução comentada

A multiplicação produz o número 7.5. A f-string monta o texto com duas casas decimais. Com zero itens a conta dá 0.0 e a mesma formatação mostra 0.00.

Saída esperada

```text
Total: 7.50
```
