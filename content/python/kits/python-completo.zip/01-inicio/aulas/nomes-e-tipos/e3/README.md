# E3 · Resolva

Monte uma ficha com título `Revisão`, duração `2.5` em horas e indicador de conclusão verdadeiro. Exiba cada valor com o nome do seu tipo. Em seguida teste uma etapa ainda pendente de duração `0.0`.

Saída esperada

```text
Revisão str
2.5 float
True bool
```
