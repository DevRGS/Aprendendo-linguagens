titulo = "Revisão"
# Defina a duração e o indicador. Em seguida mostre valor e tipo de cada campo.
