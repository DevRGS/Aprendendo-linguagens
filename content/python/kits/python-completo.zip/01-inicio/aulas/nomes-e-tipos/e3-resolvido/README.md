# Solução comentada

O título é um texto, a duração em horas é float e o indicador é bool. Ao escrever 0.0, você mantém o tipo float mesmo com valor zero. Uma etapa pendente usa o literal False.

Saída esperada

```text
Revisão str
2.5 float
True bool
```
