titulo = "Revisão"
duracao = 2.5
concluida = True
print(titulo, type(titulo).__name__)
print(duracao, type(duracao).__name__)
print(concluida, type(concluida).__name__)
