# E2 · Altere ou depure

Preveja separadamente o valor e o tipo de `"4" * 2` e de `4 * 2`. Exiba os dois pares.

Saída esperada

```text
44 str
8 int
```
