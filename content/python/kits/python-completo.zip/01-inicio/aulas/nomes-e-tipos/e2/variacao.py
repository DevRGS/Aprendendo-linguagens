codigo = "4" * 2
dobro = 4 * 2
print(codigo, type(codigo).__name__)
print(dobro, type(dobro).__name__)
