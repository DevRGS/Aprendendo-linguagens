aulas = 4
aulas = aulas + 2
print(aulas)
