# E1 · Preveja e execute

Antes de executar, diga quanto vale `aulas` depois de cada atribuição. Exiba o total depois de acrescentar duas aulas a quatro.

Saída esperada

```text
6
```
