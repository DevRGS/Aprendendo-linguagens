print("Nome: Lia")
print("Meta: ler dados")
