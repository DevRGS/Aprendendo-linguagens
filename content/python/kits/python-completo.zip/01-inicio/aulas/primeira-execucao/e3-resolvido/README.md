# Solução comentada

Cada chamada exibe uma informação e termina sua linha. Uma chamada com texto vazio ainda escreve uma quebra de linha.

Saída esperada

```text
Nome: Lia
Meta: ler dados
```
