# E1 · Preveja e execute

Antes de executar, escreva a linha que espera ver. Copie apenas a instrução abaixo e rode no ambiente escolhido.

Saída esperada

```text
Olá, mundo!
```
