# E2 · Altere ou depure

Troque somente o conteúdo entre as aspas por `Estou aprendendo`. Preveja se as aspas aparecem na saída e confira.

Saída esperada

```text
Estou aprendendo
```
