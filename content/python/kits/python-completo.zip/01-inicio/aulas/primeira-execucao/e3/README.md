# E3 · Resolva

Mostre `Nome: Lia` na primeira linha e `Meta: ler dados` na segunda. Use o ambiente que você escolheu. Qualquer solução com as duas linhas exatas funciona. Como caso de borda, teste uma mensagem vazia e observe se ela ainda ocupa uma linha.

Saída esperada

```text
Nome: Lia
Meta: ler dados
```
