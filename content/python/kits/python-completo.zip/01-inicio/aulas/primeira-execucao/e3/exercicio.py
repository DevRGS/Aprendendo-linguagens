# Escreva a primeira instrução para Nome: Lia.
# Na linha seguinte, imprima Meta: ler dados.
