# E2 · Altere ou depure

No ambiente preparado, compare `numpy.__version__` e `importlib.metadata.version("numpy")`. Qual delas vem da distribuição instalada?

Saída esperada

```text
versões coincidem: True
```
