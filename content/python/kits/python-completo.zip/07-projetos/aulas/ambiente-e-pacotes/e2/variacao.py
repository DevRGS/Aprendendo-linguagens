from importlib.metadata import version
import numpy

importada = numpy.__version__
instalada = version("numpy")
print("versões coincidem:", importada == instalada)
