import sys

executavel = sys.executable
versao = sys.version
print("versão identificada:", bool(versao))
print("versão começa com o número principal:", versao.startswith(str(sys.version_info.major)))
