# E1 · Preveja e execute

Localize `sys.executable` e `sys.version`. Depois da primeira execução, mostre os valores completos como indicado abaixo e anote-os. No terminal, repita pelo Python da .venv.

Saída esperada

```text
versão identificada: True
versão começa com o número principal: True
```
