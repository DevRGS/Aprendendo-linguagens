# E3 · Resolva

Grave `ambiente.json` com versões do Python e do NumPy e um procedimento para reproduzir a sessão. Identifique o percurso usado. Se o caminho do executável for vazio, registre isso explicitamente.

Saída esperada

```text
versões registradas: True
instruções registradas: True
caminho ausente: não informado pelo ambiente
```
