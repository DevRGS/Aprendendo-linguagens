import json
import sys
from importlib.metadata import version
from pathlib import Path

caminho = Path("ambiente.json")
# Registre as versões, salve a ficha e releia-a.
