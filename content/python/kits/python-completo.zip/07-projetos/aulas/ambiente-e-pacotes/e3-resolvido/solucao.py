import json
import sys
from importlib.metadata import version
from pathlib import Path

def ficha(executavel):
    return {
        "python": ".".join(map(str, sys.version_info[:3])),
        "numpy": version("numpy"),
        "executavel": executavel or "não informado pelo ambiente",
        "terminal": "Criar a .venv, instalar requirements.txt e rodar pelo Python da .venv",
        "caderno": "Abrir no kernel Python com NumPy, preparar e executar as células",
    }

caminho = Path("ambiente.json")
caminho.write_text(json.dumps(ficha(sys.executable), ensure_ascii=False, indent=2),
                   encoding="utf-8")
registro = json.loads(caminho.read_text(encoding="utf-8"))
print("versões registradas:", bool(registro["python"] and registro["numpy"]))
print("instruções registradas:", bool(registro["terminal"] and registro["caderno"]))
print("caminho ausente:", ficha("")["executavel"])
