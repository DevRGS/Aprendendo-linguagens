# Solução comentada

A ficha de referência registra como repetir nos dois percursos. Abra ambiente.json e acrescente o sistema e a origem do kit ou o kernel que usou. A ficha continua legível quando sys.executable está vazio.

Saída esperada

```text
versões registradas: True
instruções registradas: True
caminho ausente: não informado pelo ambiente
```
