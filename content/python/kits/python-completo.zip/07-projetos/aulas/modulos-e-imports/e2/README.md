# E2 · Altere ou depure

Investigue qual arquivo chamado csv o Python encontra se procurar primeiro na pasta `sombra`. Aqui a busca não substitui o módulo csv carregado no kernel.

Saída esperada

```text
True
csv.py
```
