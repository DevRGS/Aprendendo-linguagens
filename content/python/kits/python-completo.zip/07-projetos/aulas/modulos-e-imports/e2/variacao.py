from importlib.machinery import PathFinder
from pathlib import Path

pasta = Path("sombra").resolve()
resultado = PathFinder.find_spec("csv", [str(pasta)])
print(Path(resultado.origin).parent == pasta)
print(Path(resultado.origin).name)
