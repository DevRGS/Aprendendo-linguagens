# Arquivo local usado para investigar a busca.
