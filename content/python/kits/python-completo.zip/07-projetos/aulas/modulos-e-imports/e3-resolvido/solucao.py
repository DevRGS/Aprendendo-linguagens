from contextlib import redirect_stdout
from io import StringIO

durante_import = StringIO()
with redirect_stdout(durante_import):
    from conversoes import minutos, segundos

assert durante_import.getvalue() == ""
duracao = minutos(1, 5)
print(duracao, segundos(duracao))
print(segundos(minutos(0, 0)))
