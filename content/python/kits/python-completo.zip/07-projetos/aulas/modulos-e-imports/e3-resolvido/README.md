# Solução comentada

O auxiliar define as duas funções. O consumidor decide quando chamar e imprimir. O desvio de stdout testa o silêncio do import. Reinicie o kernel para confirmar um primeiro import após cada edição.

Saída esperada

```text
65 3900
0
```
