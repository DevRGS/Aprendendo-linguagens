def minutos(horas, restantes):
    return horas * 60 + restantes


def segundos(minutos):
    return minutos * 60
