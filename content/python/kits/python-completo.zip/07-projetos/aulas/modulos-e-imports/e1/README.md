# E1 · Preveja e execute

Confira `medidas.py` junto da atividade. Importe-o e use a função com 1 hora e 5 minutos.

Saída esperada

```text
65
```
