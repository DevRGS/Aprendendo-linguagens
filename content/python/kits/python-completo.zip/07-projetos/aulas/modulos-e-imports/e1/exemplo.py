import medidas

duracao = medidas.minutos(1, 5)
print(duracao)
