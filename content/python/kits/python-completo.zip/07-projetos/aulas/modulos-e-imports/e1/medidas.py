def minutos(horas, restantes):
    return horas * 60 + restantes
