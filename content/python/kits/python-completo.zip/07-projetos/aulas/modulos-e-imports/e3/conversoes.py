def minutos(horas, restantes):
    # Combine as duas entradas.
    raise NotImplementedError


def segundos(minutos):
    # Converta para segundos.
    raise NotImplementedError
