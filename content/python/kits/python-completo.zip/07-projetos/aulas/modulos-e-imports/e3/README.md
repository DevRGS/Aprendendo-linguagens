# E3 · Resolva

Escreva `minutos(h, m)` e `segundos(m)` no auxiliar `conversoes.py`. Importe as duas funções em um segundo arquivo, ou na célula do caderno, e mostre 65 e 3900 com (1, 5). A importação deve ser silenciosa, e zero minutos devem resultar em 0 segundos.

Saída esperada

```text
65 3900
0
```
