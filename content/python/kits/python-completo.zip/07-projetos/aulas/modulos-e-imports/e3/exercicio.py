# Defina ou reescreva as duas funções em conversoes.py.
from conversoes import minutos, segundos

# Passe o retorno da primeira para a segunda.
