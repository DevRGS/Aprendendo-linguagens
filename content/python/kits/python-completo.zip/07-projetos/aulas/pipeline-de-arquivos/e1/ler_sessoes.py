import csv

def ler_minutos(caminho):
    with caminho.open(encoding="utf-8", newline="") as arquivo:
        return [int(linha["minutos"]) for linha in csv.DictReader(arquivo)]
