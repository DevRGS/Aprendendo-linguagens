def resumir(minutos):
    return {"total": sum(minutos), "quantidade": len(minutos)}
