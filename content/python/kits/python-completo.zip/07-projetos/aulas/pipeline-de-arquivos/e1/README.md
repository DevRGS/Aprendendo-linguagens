# E1 · Preveja e execute

Encadeie as duas funções auxiliares para ler `sessoes.csv` com 3 e 7 minutos. Grave `resumo.json` e mostre o total.

Saída esperada

```text
10
```
