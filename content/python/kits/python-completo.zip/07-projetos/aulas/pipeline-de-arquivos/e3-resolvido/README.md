# Solução comentada

ler_sessoes.py converte os campos. resumir_sessoes.py calcula sem abrir arquivos, e o programa principal coordena a entrada e a saída. A célula faz o papel do principal no caderno.

Saída esperada

```text
10 2
0 0
```
