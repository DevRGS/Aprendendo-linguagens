import json
from pathlib import Path
from ler_sessoes import ler_minutos
from resumir_sessoes import resumir

def executar(origem, destino):
    minutos = ler_minutos(origem)
    resultado = resumir(minutos)
    with destino.open("w", encoding="utf-8") as arquivo:
        json.dump(resultado, arquivo)
    return resultado

executar(Path("sessoes.csv"), Path("resumo.json"))
resumo = json.loads(Path("resumo.json").read_text(encoding="utf-8"))
print(resumo["total"], resumo["quantidade"])

vazio = executar(Path("sem_sessoes.csv"), Path("resumo_vazio.json"))
print(vazio["total"], vazio["quantidade"])
