from pathlib import Path
from ler_sessoes import ler_minutos
from resumir_sessoes import resumir

origem = Path("sessoes.csv")
destino = Path("resumo.json")
# Leia, resuma e grave o destino.
