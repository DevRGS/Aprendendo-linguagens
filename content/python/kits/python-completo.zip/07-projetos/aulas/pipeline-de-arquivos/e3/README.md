# E3 · Resolva

Entregue dois auxiliares e o programa principal. Na pasta nova da atividade, coloque `sessoes.csv` junto dos três arquivos. Execute o principal a partir dessa pasta, releia `resumo.json` e confira total 10 e quantidade 2. Teste um CSV só com cabeçalho, que deve resultar em total e quantidade zero.

Saída esperada

```text
10 2
0 0
```
