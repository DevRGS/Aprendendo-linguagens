# E2 · Altere ou depure

Execute duas vezes com a mesma entrada e o mesmo destino. Compare os objetos lidos depois de cada execução. Preveja a contagem do segundo.

Saída esperada

```text
True
2
```
