import json
from pathlib import Path
from ler_sessoes import ler_minutos
from resumir_sessoes import resumir

def executar(origem, destino):
    minutos = ler_minutos(origem)
    resultado = resumir(minutos)
    with destino.open("w", encoding="utf-8") as arquivo:
        json.dump(resultado, arquivo)
    return resultado

origem = Path("sessoes.csv")
destino = Path("resumo.json")
executar(origem, destino)
primeiro = json.loads(destino.read_text(encoding="utf-8"))
executar(origem, destino)
segundo = json.loads(destino.read_text(encoding="utf-8"))
print(primeiro == segundo)
print(segundo["quantidade"])
