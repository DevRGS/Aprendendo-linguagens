from argparse import ArgumentParser

def main(args=None):
    parser = ArgumentParser(prog="relatorio")
    parser.add_argument("--limite", type=int, default=3)
    opcoes = parser.parse_args(args)
    if opcoes.limite < 0:
        parser.error("--limite deve ser >= 0")

    tarefas = ["ler", "revisar", "salvar"][:opcoes.limite]
    print(f"tarefas={len(tarefas)}")
    if tarefas:
        print(", ".join(tarefas))
