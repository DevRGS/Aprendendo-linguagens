import runpy
import sys
from contextlib import redirect_stdout
from io import StringIO
from entrada_relatorio import main

no_caderno = StringIO()
with redirect_stdout(no_caderno):
    main(["--limite", "2"])

na_cli = StringIO()
argumentos_anteriores = sys.argv
try:
    sys.argv = ["relatorio_cli.py", "--limite", "2"]
    with redirect_stdout(na_cli):
        runpy.run_path("relatorio_cli.py", run_name="__main__")
finally:
    sys.argv = argumentos_anteriores

print(no_caderno.getvalue(), end="")
print("mesmo relatório:", no_caderno.getvalue() == na_cli.getvalue())
main(["--limite", "0"])
