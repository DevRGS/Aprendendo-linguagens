# Solução comentada

main recebe a lista do caderno. O ponto de entrada chama main sem lista e o parser usa sys.argv. Zero seleciona uma fatia vazia. Valores negativos são rejeitados para que não sejam tratados como índices de fim negativos.

Saída esperada

```text
tarefas=2
ler, revisar
mesmo relatório: True
tarefas=0
```
