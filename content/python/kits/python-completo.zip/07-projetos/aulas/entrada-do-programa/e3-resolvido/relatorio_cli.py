from entrada_relatorio import main

if __name__ == "__main__":
    main()
