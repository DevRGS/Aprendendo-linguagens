from entrada_limite import main

if __name__ == "__main__":
    main()
