# E1 · Preveja e execute

Receba limite 5 pela lista explícita. No terminal da pasta E1, compare com `python3 relatorio_cli.py --limite 5` em Bash ou `py relatorio_cli.py --limite 5` em PowerShell.

Saída esperada

```text
limite: 5
```
