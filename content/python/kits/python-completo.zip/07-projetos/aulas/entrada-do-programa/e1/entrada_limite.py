from argparse import ArgumentParser

def main(args=None):
    parser = ArgumentParser()
    parser.add_argument("--limite", type=int, default=3)
    opcoes = parser.parse_args(args)
    print(f"limite: {opcoes.limite}")
