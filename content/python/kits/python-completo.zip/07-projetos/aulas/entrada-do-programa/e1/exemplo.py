from entrada_limite import main

main(["--limite", "5"])
