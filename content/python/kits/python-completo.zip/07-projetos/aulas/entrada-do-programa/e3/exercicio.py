# Em entrada_relatorio.py, implemente main com ArgumentParser.
# Em relatorio_cli.py, importe main e proteja sua chamada.
from entrada_relatorio import main

main(["--limite", "2"])
