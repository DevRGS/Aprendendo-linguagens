# E3 · Resolva

Faça `main(["--limite", "2"])` e a chamada `relatorio_cli.py --limite 2` emitirem o mesmo relatório com duas tarefas. Use 3 como padrão e 0 como seleção vazia. Na pasta E3, experimente `python3 relatorio_cli.py --limite 2` em Bash ou `py relatorio_cli.py --limite 2` em PowerShell.

Saída esperada

```text
tarefas=2
ler, revisar
mesmo relatório: True
tarefas=0
```
