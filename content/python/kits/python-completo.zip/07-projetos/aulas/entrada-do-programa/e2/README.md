# E2 · Altere ou depure

Compare análise válida, pedido de ajuda e opção não numérica. A ajuda e o erro encerrariam o processo e são capturados aqui. Determine qual usa a saída de diagnóstico.

Saída esperada

```text
5
ajuda 0 True False
erro 2 False True
```
