from argparse import ArgumentParser
from contextlib import redirect_stdout, redirect_stderr
from io import StringIO

parser = ArgumentParser(prog="relatorio")
parser.add_argument("--limite", type=int, default=3)
print(parser.parse_args(["--limite", "5"]).limite)

for rotulo, args in [("ajuda", ["--help"]), ("erro", ["--limite", "dois"])]:
    saida, diagnostico = StringIO(), StringIO()
    with redirect_stdout(saida), redirect_stderr(diagnostico):
        try:
            parser.parse_args(args)
        except SystemExit as fim:
            codigo = fim.code
    print(rotulo, codigo, bool(saida.getvalue()), bool(diagnostico.getvalue()))
