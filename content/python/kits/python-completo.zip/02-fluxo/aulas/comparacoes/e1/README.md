# E1 · Preveja e execute

Preveja se as notas 0, 10 e 11 passam por um intervalo com os dois extremos inclusivos.

Saída esperada

```text
0 True
10 True
11 False
```
