nota = 0
print(nota, 0 <= nota <= 10)
nota = 10
print(nota, 0 <= nota <= 10)
nota = 11
print(nota, 0 <= nota <= 10)
