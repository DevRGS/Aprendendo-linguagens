autorizado = True
convite = False
sala_aberta = False
print(autorizado or convite and sala_aberta)
print((autorizado or convite) and sala_aberta)
