# E2 · Altere ou depure

Calcule mentalmente os resultados antes de rodar. Compare os efeitos do agrupamento em duas regras booleanas.

Saída esperada

```text
True
False
```
