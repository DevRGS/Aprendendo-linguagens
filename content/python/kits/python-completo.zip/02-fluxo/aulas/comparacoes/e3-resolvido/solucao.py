cadastro = True
idade = 15
print(cadastro and idade >= 16)

cadastro = True
idade = 16
print(cadastro and idade >= 16)

cadastro = False
idade = 18
print(cadastro and idade >= 16)
