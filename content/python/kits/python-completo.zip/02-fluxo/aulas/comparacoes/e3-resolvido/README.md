# Solução comentada

Cada situação precisa passar pelas duas verificações. Uma pessoa cadastrada de exatamente 16 anos passa por causa da igualdade em >=.

Saída esperada

```text
False
True
False
```
