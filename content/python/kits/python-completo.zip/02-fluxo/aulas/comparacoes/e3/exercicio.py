cadastro = True
idade = 15
# Exiba a regra e repita para os outros dois casos.
