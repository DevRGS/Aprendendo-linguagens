# E3 · Resolva

Uma oficina admite quem tem cadastro e tem pelo menos 16 anos. Demonstre três casos, nesta ordem: cadastro e 15 anos, cadastro e 16 anos, sem cadastro e 18 anos. O segundo caso testa o limite inclusivo.

Saída esperada

```text
False
True
False
```
