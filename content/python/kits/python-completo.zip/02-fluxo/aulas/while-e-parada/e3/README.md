# E3 · Resolva

Leia um inteiro por vez. Digite `3`, `2` e `0`, confirmando cada linha. Mostre a quantidade de entradas anteriores ao zero e a soma delas, sem contar a sentinela. Repita com 0 como primeira entrada.

Digite cada entrada em uma linha.

```text
3
2
0
```

Saída esperada

```text
Quantidade: 2
Total: 5
```
