quantidade = 0
total = 0
while True:
    valor = int(input())
    # Teste a sentinela antes de atualizar.
    break  # Substitua pela condição de parada e pelo acúmulo.
