faltam = 3
while faltam > 0:
    print(faltam)
    faltam = faltam - 1
