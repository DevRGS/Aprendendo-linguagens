# E1 · Preveja e execute

Preveja os valores impressos antes da condição falhar. Conte de 3 até 1 com while.

Saída esperada

```text
3
2
1
```
