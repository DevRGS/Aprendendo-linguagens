# Solução comentada

A checagem antes da atualização impede que zero conte como entrada. Com 0 no primeiro pedido, ambos os acumuladores permanecem em 0. Forneça inteiros até o zero para encerrar.

Digite cada entrada em uma linha.

```text
3
2
0
```

Saída esperada

```text
Quantidade: 2
Total: 5
```
