quantidade = 0
total = 0
while True:
    valor = int(input())
    if valor == 0:
        break
    quantidade = quantidade + 1
    total = total + valor
print("Quantidade:", quantidade)
print("Total:", total)
