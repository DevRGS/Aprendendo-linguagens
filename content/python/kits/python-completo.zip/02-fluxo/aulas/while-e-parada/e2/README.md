# E2 · Altere ou depure

No papel, trace o trecho intencionalmente incompleto `faltam = 2` seguido de `while faltam > 0: print(faltam)`. Qual valor se repetiria? Escreva a atualização que falta antes de executar a versão corrigida abaixo.

Saída esperada

```text
2
1
Fim
```
