faltam = 2
while faltam > 0:
    print(faltam)
    faltam = faltam - 1
print("Fim")
