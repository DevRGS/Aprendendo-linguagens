# E1 · Preveja e execute

Preveja o rótulo da nota 7 quando a aprovação exige pelo menos 7. Rode e identifique as linhas dentro do bloco.

Saída esperada

```text
aprovada
```
