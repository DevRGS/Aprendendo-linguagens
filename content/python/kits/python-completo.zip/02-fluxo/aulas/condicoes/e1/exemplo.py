nota = 7
if nota >= 7:
    print("aprovada")
else:
    print("abaixo de 7")
