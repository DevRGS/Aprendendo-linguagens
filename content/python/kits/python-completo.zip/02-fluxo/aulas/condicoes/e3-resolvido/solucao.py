notas = [-1, 5, 7, 11]
for nota in notas:
    if nota < 0 or nota > 10:
        print("inválida")
    elif nota >= 7:
        print("aprovada")
    elif nota >= 5:
        print("recuperação")
    else:
        print("reprovada")
