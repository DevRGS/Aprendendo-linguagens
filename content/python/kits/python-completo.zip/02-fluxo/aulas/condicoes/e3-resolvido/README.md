# Solução comentada

A validação é primeira para evitar que 11 satisfaça indevidamente a aprovação. O limite 10 é válido. O for repete a cadeia para cada nota e será explicado na próxima aula.

Saída esperada

```text
inválida
recuperação
aprovada
inválida
```
