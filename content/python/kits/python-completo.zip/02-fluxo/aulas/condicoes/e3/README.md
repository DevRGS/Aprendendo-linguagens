# E3 · Resolva

Classifique notas de 0 a 10 com esta precedência: inválida fora da faixa, aprovada a partir de 7, recuperação a partir de 5, reprovada nos demais casos. Teste −1, 5, 7 e 11 nessa ordem. Inclua também a borda 10 na conferência.

Saída esperada

```text
inválida
recuperação
aprovada
inválida
```
