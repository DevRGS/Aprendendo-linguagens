notas = [-1, 5, 7, 11]
# O for fornece uma nota por vez. Use if/elif/else dentro dele.
for nota in notas:
    pass  # Substitua esta linha pelo primeiro teste e complete os blocos.
