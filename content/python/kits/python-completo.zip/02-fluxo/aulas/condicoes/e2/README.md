# E2 · Altere ou depure

A nota 6 deve ir para recuperação. Compare a primeira cadeia, intencionalmente mal ordenada, com a correção. Preveja qual condição esconde a recuperação.

Saída esperada

```text
abaixo de 7
recuperação
```
