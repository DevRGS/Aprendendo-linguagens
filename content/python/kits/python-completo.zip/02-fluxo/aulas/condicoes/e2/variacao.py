nota = 6
if nota < 7:
    print("abaixo de 7")
elif nota >= 5 and nota < 7:
    print("recuperação")

if nota >= 7:
    print("aprovada")
elif nota >= 5:
    print("recuperação")
else:
    print("reprovada")
