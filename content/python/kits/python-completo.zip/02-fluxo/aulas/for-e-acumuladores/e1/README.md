# E1 · Preveja e execute

Anote os quatro totais esperados antes de executar. Some 1 até 4 e mostre o acumulador depois de cada adição.

Saída esperada

```text
1
3
6
10
```
