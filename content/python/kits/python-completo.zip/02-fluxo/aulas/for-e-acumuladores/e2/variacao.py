total = 0
for numero in range(1, 4):
    total = total + numero
print(total)

total = 0
for numero in range(1, 5):
    total = total + numero
print(total)
