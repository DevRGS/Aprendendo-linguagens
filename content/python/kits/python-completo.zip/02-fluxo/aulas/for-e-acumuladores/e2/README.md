# E2 · Altere ou depure

Diga qual número está faltando na primeira contagem e por quê. Compare o total de cada intervalo.

Saída esperada

```text
6
10
```
