total = 0
for numero in range(2, 11, 2):
    total = total + numero
print(total)
