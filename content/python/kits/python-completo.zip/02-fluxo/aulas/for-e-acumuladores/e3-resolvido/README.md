# Solução comentada

O passo 2 produz 2, 4, 6, 8 e 10. Se o primeiro valor já alcança o limite final, o corpo não roda e total conserva o zero inicial.

Saída esperada

```text
30
```
