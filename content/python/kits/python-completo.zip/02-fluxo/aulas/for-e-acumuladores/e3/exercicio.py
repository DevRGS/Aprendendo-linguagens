total = 0
# Percorra os pares, atualize total e exiba o resultado.
