# E3 · Resolva

Some apenas os números pares de 2 até 10, incluindo 10. Mostre só o total. Como caso de borda, use um intervalo em que não entre nenhum par e confira o resultado.

Saída esperada

```text
30
```
