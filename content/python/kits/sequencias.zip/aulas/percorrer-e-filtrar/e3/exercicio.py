medicoes = [3, None, 0, None]
ausentes = []
# Encontre e exiba os índices dos ausentes.
