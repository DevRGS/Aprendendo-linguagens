# E3 · Resolva

Localize os índices de valores ausentes em [3, None, 0, None]. Use None como único marcador de ausência e mantenha a lista original. Mostre os índices. Depois teste [0], que deve produzir lista de índices vazia.

Saída esperada

```text
[1, 3]
```
