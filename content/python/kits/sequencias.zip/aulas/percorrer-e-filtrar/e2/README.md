# E2 · Altere ou depure

Antes de executar, diga qual é a posição do zero e qual valor está na posição zero. Exiba cada posição junto do valor.

Saída esperada

```text
0 -1
1 2
2 0
3 4
```
