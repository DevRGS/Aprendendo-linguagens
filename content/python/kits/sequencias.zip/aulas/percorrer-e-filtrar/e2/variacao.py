temperaturas = [-1, 2, 0, 4]
for indice, temperatura in enumerate(temperaturas):
    print(indice, temperatura)
