# E1 · Preveja e execute

Preveja quais itens de [−1, 2, 0, 4] passam pelo limite estrito. Construa uma lista contendo só temperaturas positivas.

Saída esperada

```text
[2, 4]
```
