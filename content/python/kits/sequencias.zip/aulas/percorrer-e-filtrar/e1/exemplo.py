temperaturas = [-1, 2, 0, 4]
positivas = []
for temperatura in temperaturas:
    if temperatura > 0:
        positivas.append(temperatura)
print(positivas)
