medicoes = [3, None, 0, None]
ausentes = []
for indice, valor in enumerate(medicoes):
    if valor is None:
        ausentes.append(indice)
print(ausentes)
