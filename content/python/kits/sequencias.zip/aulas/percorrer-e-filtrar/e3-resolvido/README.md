# Solução comentada

Guardamos o índice quando o item é None. Zero é uma medição presente. A lista [0] tem uma medição e nenhum índice de ausência.

Saída esperada

```text
[1, 3]
```
