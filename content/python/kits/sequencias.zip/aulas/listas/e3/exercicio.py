original = [4, 6, 4]
# Crie outra lista e faça as mudanças apenas nela.
