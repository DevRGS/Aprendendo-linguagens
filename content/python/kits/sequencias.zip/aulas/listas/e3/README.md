# E3 · Resolva

Parta de [4, 6, 4]. Faça uma cópia, remova dela só a primeira ocorrência de 4 e acrescente 8. Exiba o original e a cópia, nessa ordem. Confira também se acrescentar à cópia de uma lista vazia deixa o original vazio.

Saída esperada

```text
[4, 6, 4]
[6, 4, 8]
```
