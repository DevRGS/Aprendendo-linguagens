# E2 · Altere ou depure

Preveja o conteúdo do original, do nome compartilhado e da cópia ao alterar o primeiro item pelo nome compartilhado.

Saída esperada

```text
[9, 6]
[9, 6]
[4, 6]
```
