original = [4, 6]
compartilhada = original
copia = original.copy()
compartilhada[0] = 9
print(original)
print(compartilhada)
print(copia)
