# Solução comentada

A cópia tem estrutura externa própria. remove atua pela primeira ocorrência do valor. O caso vazio testa apenas append, pois uma lista vazia não contém 4 para remover.

Saída esperada

```text
[4, 6, 4]
[6, 4, 8]
```
