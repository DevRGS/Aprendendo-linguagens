original = [4, 6, 4]
ajustada = original.copy()
ajustada.remove(4)
ajustada.append(8)
print(original)
print(ajustada)
