medidas = [4, 6]
medidas.append(8)
print(medidas)
