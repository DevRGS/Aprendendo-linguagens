# E1 · Preveja e execute

Preveja a posição de 8 depois de acrescentá-lo a [4, 6]. Mostre a lista resultante.

Saída esperada

```text
[4, 6, 8]
```
