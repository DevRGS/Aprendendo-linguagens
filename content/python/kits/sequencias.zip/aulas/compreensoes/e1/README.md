# E1 · Preveja e execute

Preveja o resultado de dobrar [1, 2, 3]. Execute o laço e a compreensão e compare as listas.

Saída esperada

```text
[2, 4, 6]
[2, 4, 6]
```
