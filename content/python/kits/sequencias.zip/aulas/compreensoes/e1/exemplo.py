dados = [1, 2, 3]
pelo_laco = []
for valor in dados:
    pelo_laco.append(valor * 2)

pela_compreensao = [valor * 2 for valor in dados]
print(pelo_laco)
print(pela_compreensao)
