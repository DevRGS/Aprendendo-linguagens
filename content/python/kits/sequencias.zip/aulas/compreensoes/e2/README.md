# E2 · Altere ou depure

Preveja a diferença entre selecionar os pares originais e selecionar os pares já dobrados em [1, 2, 3]. Escreva as duas etapas da segunda abordagem.

Saída esperada

```text
[4]
[2, 4, 6]
```
