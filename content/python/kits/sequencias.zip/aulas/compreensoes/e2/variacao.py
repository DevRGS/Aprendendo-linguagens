dados = [1, 2, 3]
dobro_dos_pares = [valor * 2 for valor in dados if valor % 2 == 0]
dobros = [valor * 2 for valor in dados]
pares_dos_dobros = [valor for valor in dobros if valor % 2 == 0]
print(dobro_dos_pares)
print(pares_dos_dobros)
