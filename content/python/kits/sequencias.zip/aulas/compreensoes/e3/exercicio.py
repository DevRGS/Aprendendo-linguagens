numeros = range(6)
# Construa a compreensão e exiba seu resultado.
