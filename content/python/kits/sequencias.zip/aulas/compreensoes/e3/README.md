# E3 · Resolva

Use uma compreensão para produzir o quadrado de cada inteiro par de 0 até 5. Confira o resultado também com uma sequência vazia.

Saída esperada

```text
[0, 4, 16]
```
