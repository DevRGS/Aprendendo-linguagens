# Solução comentada

O teste deixa 0, 2 e 4 passarem. O produto do valor por ele mesmo calcula o quadrado. Uma entrada vazia produz [] porque nenhuma expressão é avaliada.

Saída esperada

```text
[0, 4, 16]
```
