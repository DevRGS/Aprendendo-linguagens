numeros = range(6)
quadrados = [numero * numero for numero in numeros if numero % 2 == 0]
print(quadrados)
