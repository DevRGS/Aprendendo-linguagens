# E3 · Resolva

Receba `" azul , verde "`, separe pela vírgula e retire os espaços das extremidades de cada palavra. Imprima uma por linha. Depois observe o segundo campo de `"azul,"`: preserve a posição mesmo quando o campo está vazio.

Saída esperada

```text
azul
verde
```
