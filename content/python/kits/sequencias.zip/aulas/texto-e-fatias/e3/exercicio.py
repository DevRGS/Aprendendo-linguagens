texto = " azul , verde "
# Separe pela vírgula e limpe cada campo.
