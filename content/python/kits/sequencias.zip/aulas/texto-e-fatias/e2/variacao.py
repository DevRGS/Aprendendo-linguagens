texto = ""
print("Fatia:", repr(texto[:1]))
try:
    print(texto[0])
except IndexError:
    print("IndexError")
