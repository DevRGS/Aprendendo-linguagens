# E2 · Altere ou depure

Compare a fatia [:1] do texto vazio com o acesso intencionalmente inválido ao índice 0. Preveja qual operação retorna normalmente. O bloco captura o erro para que o exemplo termine.

Saída esperada

```text
Fatia: ''
IndexError
```
