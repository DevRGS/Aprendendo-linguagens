# Solução comentada

O separador tira a vírgula e preserva os campos. Aplicar strip a cada campo remove também espaços próximos da vírgula. Com vírgula final, o segundo campo existe e é vazio.

Saída esperada

```text
azul
verde
```
