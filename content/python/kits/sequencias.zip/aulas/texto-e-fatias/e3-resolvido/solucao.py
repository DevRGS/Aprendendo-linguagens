texto = " azul , verde "
campos = texto.split(",")
print(campos[0].strip())
print(campos[1].strip())
