# E1 · Preveja e execute

Preveja o texto depois de cada método. Normalize o nome com espaços e maiúscula inicial.

Saída esperada

```text
ana
```
