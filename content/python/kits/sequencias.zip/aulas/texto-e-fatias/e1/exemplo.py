bruto = " Ana "
sem_espacos = bruto.strip()
normalizado = sem_espacos.lower()
print(normalizado)
