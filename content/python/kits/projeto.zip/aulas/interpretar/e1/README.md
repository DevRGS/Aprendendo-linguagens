# E1 · Preveja e execute

Resuma o alvo do treino em minutos.

Saída esperada

```text
[6.0, 8.0, 10.0, 10.0, 12.0, 14.0]
mínimo=6.0 mediana=10.0 máximo=14.0
```
