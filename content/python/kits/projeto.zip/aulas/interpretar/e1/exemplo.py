from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

from preparacao_viagens import ajustar, aplicar, exportar, extrair, particionar
partes = particionar(validas)
parametros = ajustar(partes["treino"])

from statistics import median
alvos = partes["treino"]["minutos_reais"].tolist()
print(alvos)
print(f"mínimo={min(alvos):.1f} mediana={median(alvos):.1f} máximo={max(alvos):.1f}")
