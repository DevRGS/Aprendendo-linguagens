# Solução comentada

No teste, os alvos 18 e 22 estão a 8 e 12 minutos da previsão. A média é 10. O relatório inclui título, eixos, descrição e tabela com os valores do treino. Em uma avaliação com pouquíssimas observações, um valor novo pode mudar a métrica substancialmente.

Saída esperada

```text
True
{'validacao': 3.5, 'teste': 10.0}
```
