from pathlib import Path
from executar_projeto import executar, mostrar

pasta = Path.cwd()
resultados = executar(pasta/"dados/viagens.csv", pasta/"dados/estacoes.csv", pasta/"saida")

_, _, _, metricas = resultados
assert metricas == {"validacao":3.5, "teste":10.0}
print(Path("saida/relatorio.md").is_file())
print(metricas)
