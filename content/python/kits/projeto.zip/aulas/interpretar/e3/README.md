# E3 · Resolva

Congele a referência. Calcule então o erro de teste e exporte um relatório com gráfico de treino, tabela, unidade e limites.

Saída esperada

```text
True
{'validacao': 3.5, 'teste': 10.0}
```
