from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

from preparacao_viagens import ajustar, aplicar, exportar, extrair, particionar
partes = particionar(validas)
parametros = ajustar(partes["treino"])

from preparacao_viagens import mae
ref = parametros["referencia_minutos"]
alvos = partes["validacao"]["minutos_reais"]
print([abs(y-ref) for y in alvos])
print(mae(alvos, ref))
