# E2 · Altere ou depure

Calcule à mão os erros absolutos de 10 contra alvos de validação 8 e 15, e compare.

Saída esperada

```text
[2.0, 5.0]
3.5
```
