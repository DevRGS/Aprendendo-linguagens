# Solução comentada

V11 falha pelo domínio, V04 aparece uma vez na saída e V08 permanece mesmo com estação desconhecida. V07 tem valor alto porém válido. Um conflito de ID deve produzir erro em vez de apagar uma versão. A solução inclui as regras no arquivo auditoria_viagens.py.

Saída esperada

```text
12 10
{'V04': 1}
{'V11': ['km_planejados negativo']}
['V03', 'V08'] ['V08']
```
