from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

from auditoria_viagens import salvar_json
salvar_json(Path("auditoria.json"), auditoria)
assert set(validas["id"]) == {f"V{i:02}" for i in range(1, 11)}
print(auditoria["linhas_brutas"], auditoria["linhas_validas"])
print(auditoria["duplicatas_excedentes"])
print(auditoria["rejeitadas"])
print(auditoria["km_ausentes_validas"], auditoria["viagens_sem_cadastro"])
