import pandas as pd
brutas = pd.read_csv("dados/viagens.csv")
estacoes = pd.read_csv("dados/estacoes.csv")
# Preserve brutas. Registre os motivos de cada exclusão e faça a junção.
