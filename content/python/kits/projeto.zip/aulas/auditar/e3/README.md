# E3 · Resolva

Produza auditoria.json com contagem antes e depois, motivos, unidades e IDs. Faça uma junção que preserve viagens e identifique a estação ausente.

Saída esperada

```text
12 10
{'V04': 1}
{'V11': ['km_planejados negativo']}
['V03', 'V08'] ['V08']
```
