import pandas as pd
viagens = pd.read_csv("dados/viagens.csv", dtype={"id":"string"})
estacoes = pd.read_csv("dados/estacoes.csv", dtype="string")
print(viagens.shape)
print(estacoes["estacao"].tolist())
print(viagens["id"].iloc[0])
