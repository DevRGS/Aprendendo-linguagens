# E1 · Preveja e execute

Leia os dois CSVs e conte observações antes de limpar.

Saída esperada

```text
(12, 7)
['A', 'B']
V01
```
