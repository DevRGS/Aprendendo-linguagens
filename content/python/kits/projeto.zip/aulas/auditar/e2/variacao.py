import pandas as pd
brutas = pd.read_csv("dados/viagens.csv")
print(brutas.loc[brutas.duplicated(), "id"].tolist())
print(brutas.loc[brutas["km_planejados"].isna(), "id"].tolist())
print(brutas.loc[brutas["paradas_planejadas"].eq(0), "id"].tolist())
