# E2 · Altere ou depure

Localize a cópia extra, as distâncias ausentes e os zeros de paradas, sem editar os dados.

Saída esperada

```text
['V04']
['V03', 'V08']
['V01', 'V08']
```
