# E2 · Altere ou depure

Adicione uma linha com V01 divergente a uma cópia da tabela e confira o diagnóstico.

Saída esperada

```text
ID em conflito: V01
```
