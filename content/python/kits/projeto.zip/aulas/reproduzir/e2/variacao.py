from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

import pandas as pd
mudada = brutas.loc[brutas["id"].eq("V01")].assign(km_planejados=99.0)
try:
    auditar(pd.concat([brutas, mudada], ignore_index=True), estacoes)
except ValueError as erro:
    print(erro)
else:
    raise AssertionError("o conflito deveria interromper a auditoria")
