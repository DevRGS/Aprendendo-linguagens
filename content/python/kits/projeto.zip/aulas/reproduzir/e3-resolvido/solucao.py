from pathlib import Path
from executar_projeto import executar, mostrar

pasta = Path.cwd()
resultados = executar(pasta/"dados/viagens.csv", pasta/"dados/estacoes.csv", pasta/"saida")

from io import StringIO
import unittest
from testes_projeto import ProjetoTest

suite = unittest.defaultTestLoader.loadTestsFromTestCase(ProjetoTest)
teste = unittest.TextTestRunner(stream=StringIO()).run(suite)
if not teste.wasSuccessful():
    for _, falha in teste.failures + teste.errors:
        print(falha)
    raise AssertionError("algum controle falhou")
print(teste.testsRun, "testes do projeto passaram")
mostrar(*resultados)
