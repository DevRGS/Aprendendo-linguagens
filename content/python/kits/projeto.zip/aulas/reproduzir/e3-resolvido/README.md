# Solução comentada

Com as datas trocadas, V07 passa a encerrar o treino e V06 entra na validação. O máximo aprendido passa a 100 e a mediana de y passa a 9. Use IDs para verificar alinhamento, X para entrada e y para alvo. Mantenha os parâmetros com a entrega para reproduzir o tratamento em novas viagens.

Saída esperada

```text
7 testes do projeto passaram
Auditoria: 12 brutas, 10 válidas.
Mediana de km no treino: 4.0
treino (6, 2) (6,) ['V01', 'V02', 'V03', 'V04', 'V05', 'V06']
validacao (2, 2) (2,) ['V07', 'V08']
teste (2, 2) (2,) ['V09', 'V10']
MAE de validação: 3.5 min
MAE de teste: 10.0 min
```
