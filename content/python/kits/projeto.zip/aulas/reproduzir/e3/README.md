# E3 · Resolva

Execute os testes, troque as datas de V06 e V07 em uma cópia e explique como X, y e os parâmetros irão chegar a um futuro modelo.

Saída esperada

```text
7 testes do projeto passaram
Auditoria: 12 brutas, 10 válidas.
Mediana de km no treino: 4.0
treino (6, 2) (6,) ['V01', 'V02', 'V03', 'V04', 'V05', 'V06']
validacao (2, 2) (2,) ['V07', 'V08']
teste (2, 2) (2,) ['V09', 'V10']
MAE de validação: 3.5 min
MAE de teste: 10.0 min
```
