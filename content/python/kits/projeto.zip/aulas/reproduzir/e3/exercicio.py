from pathlib import Path
from executar_projeto import executar, mostrar

pasta = Path.cwd()
resultados = executar(pasta/"dados/viagens.csv", pasta/"dados/estacoes.csv", pasta/"saida")
# Use os testes do projeto e registre as variações com uma cópia dos dados.
