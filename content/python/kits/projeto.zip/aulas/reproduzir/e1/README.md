# E1 · Preveja e execute

Execute o projeto do início com os dados originais e registre o resultado.

Saída esperada

```text
Auditoria: 12 brutas, 10 válidas.
Mediana de km no treino: 4.0
treino (6, 2) (6,) ['V01', 'V02', 'V03', 'V04', 'V05', 'V06']
validacao (2, 2) (2,) ['V07', 'V08']
teste (2, 2) (2,) ['V09', 'V10']
MAE de validação: 3.5 min
MAE de teste: 10.0 min
```
