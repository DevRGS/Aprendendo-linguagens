# Solução comentada

Os shapes preservam a contagem de viagens. As duas colunas de X têm ordem fixa. V07 e V10 ficam acima de 1, pois excedem o máximo do treino. V08 usa o preenchimento aprendido no treino e preserva zero paradas. Verifique um treino constante para testar a regra da amplitude.

Saída esperada

```text
treino (6, 2) (6,)
validacao (2, 2) (2,)
teste (2, 2) (2,)
controles conferidos
```
