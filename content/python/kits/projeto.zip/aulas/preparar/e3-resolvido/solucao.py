from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

from preparacao_viagens import ajustar, aplicar, exportar, extrair, particionar
partes = particionar(validas)
parametros = ajustar(partes["treino"])

from math import isclose
from auditoria_viagens import salvar_json
pasta = Path("saida")
pasta.mkdir(exist_ok=True)
salvar_json(pasta/"parametros.json", parametros)
tabelas = exportar(partes, parametros, pasta)
for nome, tabela in tabelas.items():
    X, y, ids = extrair(tabela)
    print(nome, X.shape, y.shape)
valores = {"V01":(0,0), "V03":(1/3,1), "V07":(98/6,1), "V08":(1/3,0), "V09":(.5,2), "V10":(7/6,3)}
for t in tabelas.values():
    for chave, km, paradas in t[["id","km_escalados","paradas_planejadas"]].itertuples(index=False):
        if chave in valores:
            a, b = valores[chave]
            assert isclose(km, a, rel_tol=0, abs_tol=1e-6) and paradas == b
print("controles conferidos")
