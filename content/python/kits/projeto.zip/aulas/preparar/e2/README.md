# E2 · Altere ou depure

Em treino apenas, copie faturamento como se fosse uma previsão. Meça o erro e explique por que não usar a coluna.

Saída esperada

```text
0.0 min
['km_escalados', 'paradas_planejadas']
```
