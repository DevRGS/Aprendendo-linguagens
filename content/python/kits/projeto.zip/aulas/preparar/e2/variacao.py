from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

from preparacao_viagens import ajustar, aplicar, exportar, extrair, particionar
partes = particionar(validas)
parametros = ajustar(partes["treino"])

treino = partes["treino"]
erro = (treino["minutos_faturados"] - treino["minutos_reais"]).abs().mean()
print(f"{erro:.1f} min")
print(parametros["atributos"])
