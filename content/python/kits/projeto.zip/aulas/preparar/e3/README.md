# E3 · Resolva

Exporte as três partições e parametros.json. Confira formas, ordem das colunas e os controles de V01, V03, V07, V08, V09 e V10.

Saída esperada

```text
treino (6, 2) (6,)
validacao (2, 2) (2,)
teste (2, 2) (2,)
controles conferidos
```
