from pathlib import Path
from auditoria_viagens import auditar, ler_estacoes, ler_viagens

brutas = ler_viagens(Path("dados/viagens.csv"))
estacoes = ler_estacoes(Path("dados/estacoes.csv"))
validas, auditoria = auditar(brutas, estacoes)

from preparacao_viagens import ajustar, aplicar, exportar, extrair, particionar
partes = particionar(validas)
parametros = ajustar(partes["treino"])

for nome, parte in partes.items():
    print(nome, parte["id"].tolist())
ids = [set(p["id"]) for p in partes.values()]
assert all(not a & b for i, a in enumerate(ids) for b in ids[i+1:])
