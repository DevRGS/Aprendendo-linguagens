# E1 · Preveja e execute

Construa partições cronológicas e confira as chaves em cada conjunto.

Saída esperada

```text
treino ['V01', 'V02', 'V03', 'V04', 'V05', 'V06']
validacao ['V07', 'V08']
teste ['V09', 'V10']
```
