# E3 · Resolva

Use data e ID para organizar seis registros abaixo. Treino até 02/01, validação em 03/01 e teste depois. Mostre IDs em ordem, prove disjunção, registre fronteiras e trate o caso de dois registros na data-limite de treino.

Saída esperada

```text
Fins inclusivos: 2026-01-02 2026-01-03
treino ['d', 'e', 'f']
validacao ['a']
teste ['b', 'c']
```
