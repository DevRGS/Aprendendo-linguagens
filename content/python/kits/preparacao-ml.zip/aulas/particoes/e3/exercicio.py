registros = [
    ("2026-01-04", "b"), ("2026-01-02", "f"), ("2026-01-01", "d"),
    ("2026-01-03", "a"), ("2026-01-02", "e"), ("2026-01-05", "c"),
]
fim_treino, fim_validacao = "2026-01-02", "2026-01-03"
# Separe as partes e use conjuntos para conferir disjunção.
