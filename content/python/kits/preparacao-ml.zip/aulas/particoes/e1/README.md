# E1 · Preveja e execute

Crie dez dias em ordem invertida. Ordene e separe primeiros seis, próximos dois e últimos dois.

Saída esperada

```text
6 2026-01-01 2026-01-06
2 2026-01-07 2026-01-08
2 2026-01-09 2026-01-10
```
