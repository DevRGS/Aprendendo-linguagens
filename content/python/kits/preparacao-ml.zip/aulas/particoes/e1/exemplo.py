dias = [f"2026-01-{dia:02d}" for dia in range(10, 0, -1)]
dias.sort()
treino, validacao, teste = dias[:6], dias[6:8], dias[8:]
for parte in (treino, validacao, teste):
    print(len(parte), parte[0], parte[-1])
