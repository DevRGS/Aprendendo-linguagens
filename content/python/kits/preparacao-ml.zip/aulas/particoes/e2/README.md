# E2 · Altere ou depure

Simule um sistema que memoriza duração por evento e prevê zero para evento novo. Compare a avaliação num registro repetido de E1 e num evento inédito E3.

Saída esperada

```text
E1 0
E3 12
```
