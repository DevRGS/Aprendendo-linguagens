treino = {"E1": 9, "E2": 15}
for id_evento, real in [("E1", 9), ("E3", 12)]:
    previsto = treino.get(id_evento, 0)
    print(id_evento, abs(real - previsto))
