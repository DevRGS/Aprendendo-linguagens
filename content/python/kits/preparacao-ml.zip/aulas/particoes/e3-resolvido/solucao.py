registros = [
    ("2026-01-04", "b"), ("2026-01-02", "f"), ("2026-01-01", "d"),
    ("2026-01-03", "a"), ("2026-01-02", "e"), ("2026-01-05", "c"),
]
fim_treino, fim_validacao = "2026-01-02", "2026-01-03"
ordenados = sorted(registros)
partes = [
    [id_ for data, id_ in ordenados if data <= fim_treino],
    [id_ for data, id_ in ordenados if fim_treino < data <= fim_validacao],
    [id_ for data, id_ in ordenados if data > fim_validacao],
]
treino, validacao, teste = map(set, partes)
assert treino.isdisjoint(validacao) and treino.isdisjoint(teste)
assert validacao.isdisjoint(teste)
assert len(treino | validacao | teste) == len(registros)
print("Fins inclusivos:", fim_treino, fim_validacao)
for nome, ids in zip(("treino", "validacao", "teste"), partes, strict=True):
    print(nome, ids)
