# Solução comentada

Os dois registros de 02/01 ficam juntos no treino e são ordenados pelo ID dentro do mesmo dia. O teste começa depois de 03/01. Ajuste parâmetros só depois de separar os conjuntos.

Saída esperada

```text
Fins inclusivos: 2026-01-02 2026-01-03
treino ['d', 'e', 'f']
validacao ['a']
teste ['b', 'c']
```
