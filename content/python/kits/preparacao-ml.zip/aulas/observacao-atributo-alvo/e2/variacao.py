import pandas as pd

df = pd.DataFrame({
    "id": ["a", "b"], "km_planejados": [2, 5],
    "minutos_reais": [6, 12], "chegada_real": ["08:06", "09:12"],
})
atributos = ["km_planejados"]
metadados = ["id"]
alvo = "minutos_reais"
excluidas = [nome for nome in df if nome not in [*atributos, *metadados, alvo]]
print("X:", atributos, "y:", alvo)
print("Rastreio:", metadados, "Pós-partida:", excluidas)
