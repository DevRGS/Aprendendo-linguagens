# E2 · Altere ou depure

Adicione o horário real de chegada. Separe as colunas em atributos, rastreio, alvo e informação pós-partida excluída.

Saída esperada

```text
X: ['km_planejados'] y: minutos_reais
Rastreio: ['id'] Pós-partida: ['chegada_real']
```
