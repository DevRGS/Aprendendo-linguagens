# E1 · Preveja e execute

Em duas viagens, separe quilômetros planejados e duração real. Confira um atributo por viagem e um alvo por viagem.

Saída esperada

```text
(2, 1) [[2], [5]]
(2,) [6, 12]
```
