import pandas as pd

df = pd.DataFrame({"id": ["a", "b"], "km_planejados": [2, 5], "minutos_reais": [6, 12]})
X = df[["km_planejados"]].to_numpy()
y = df["minutos_reais"].to_numpy()
print(X.shape, X.tolist())
print(y.shape, y.tolist())
