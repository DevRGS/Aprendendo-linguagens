import pandas as pd

def separar(df):
    atributos = ["km_planejados", "paradas_planejadas"]
    return df[atributos].to_numpy(), df["minutos_reais"].to_numpy(), df["id"].tolist()

df = pd.DataFrame({
    "id": ["b", "a"], "km_planejados": [5, 2], "paradas_planejadas": [1, 0],
    "chegada_real": ["09:12", "08:06"], "minutos_reais": [12, 6],
})
contrato = {
    "id": "antes, chave, rastreio",
    "km_planejados": "antes, km, atributo",
    "paradas_planejadas": "antes, contagem, atributo",
    "chegada_real": "depois, horário local, fora de X",
    "minutos_reais": "depois, min, alvo",
}
for coluna, descricao in contrato.items():
    print(coluna, descricao)
X, y, ids = separar(df)
print(X.shape, y.shape, ids)
assert X.tolist() == [[5, 1], [2, 0]] and y.tolist() == [12, 6]
unica, alvo_unico, ids_unicos = separar(df.iloc[:1])
assert unica.shape == (1, 2) and alvo_unico.shape == (1,) and ids_unicos == ["b"]
