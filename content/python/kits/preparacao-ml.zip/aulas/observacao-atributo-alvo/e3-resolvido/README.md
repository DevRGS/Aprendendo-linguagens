# Solução comentada

Cada linha de X está ligada à mesma posição de y por seu ID. A forma funciona mesmo com uma linha. Em seguida, os grupos inteiros serão divididos em partições por data.

Saída esperada

```text
id antes, chave, rastreio
km_planejados antes, km, atributo
paradas_planejadas antes, contagem, atributo
chegada_real depois, horário local, fora de X
minutos_reais depois, min, alvo
(2, 2) (2,) ['b', 'a']
```
