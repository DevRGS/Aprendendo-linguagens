# E3 · Resolva

Documente a disponibilidade, unidade e papel das cinco colunas abaixo. Extraia X e y na ordem das mesmas linhas, incluindo duas viagens de dados deliberadamente fora de ordem alfabética. Confira também uma entrada de uma única viagem.

Saída esperada

```text
id antes, chave, rastreio
km_planejados antes, km, atributo
paradas_planejadas antes, contagem, atributo
chegada_real depois, horário local, fora de X
minutos_reais depois, min, alvo
(2, 2) (2,) ['b', 'a']
```
