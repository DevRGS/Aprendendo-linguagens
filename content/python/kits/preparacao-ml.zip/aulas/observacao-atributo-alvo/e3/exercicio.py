import pandas as pd

df = pd.DataFrame({
    "id": ["b", "a"], "km_planejados": [5, 2], "paradas_planejadas": [1, 0],
    "chegada_real": ["09:12", "08:06"], "minutos_reais": [12, 6],
})
# Defina o contrato e preserve os IDs ao selecionar X e y.
