from statistics import mean, median

def mae(alvos, previsao):
    if not alvos:
        raise ValueError("MAE requer uma observação")
    return mean(abs(real - previsao) for real in alvos)

treino = [12, 15, 18]
validacao = [14, 19]
referencia = median(treino)
print(f"Referência (mediana do treino): {referencia:.1f} min")
print(f"MAE de validação: {mae(validacao, referencia):.1f} min")
assert mae([15], referencia) == 0
try:
    mae([], referencia)
except ValueError as erro:
    print(erro)
