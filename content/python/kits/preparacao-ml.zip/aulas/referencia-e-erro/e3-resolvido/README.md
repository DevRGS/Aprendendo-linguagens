# Solução comentada

Com erros de 1 e 4 min, a média de validação é 2,5 min. Com um único caso, o MAE é o seu erro. A média de nenhum erro observado fica indefinida. No projeto, o teste será avaliado após congelar a referência.

Saída esperada

```text
Referência (mediana do treino): 15.0 min
MAE de validação: 2.5 min
MAE requer uma observação
```
