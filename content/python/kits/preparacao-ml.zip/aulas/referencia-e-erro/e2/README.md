# E2 · Altere ou depure

Use previsão 10 min e alvos de validação 8 e 15 min. Mostre a lista de erros e a média.

Saída esperada

```text
[2, 5]
MAE: 3.5 min
```
