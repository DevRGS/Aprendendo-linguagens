from statistics import mean

previsao = 10
erros = [abs(real - previsao) for real in [8, 15]]
print(erros)
print(f"MAE: {mean(erros)} min")
