from statistics import mean, median

treino, validacao = [12, 15, 18], [14, 19]
# Defina a referência e calcule a média dos erros absolutos.
