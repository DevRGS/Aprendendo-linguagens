# E3 · Resolva

Documente a referência mediana do treino [12,15,18] e calcule o MAE em validação [14,19]. Mantenha os valores de teste reservados. Defina como lidar com uma única observação e uma partição vazia.

Saída esperada

```text
Referência (mediana do treino): 15.0 min
MAE de validação: 2.5 min
MAE requer uma observação
```
