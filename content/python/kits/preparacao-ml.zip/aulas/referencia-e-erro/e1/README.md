# E1 · Preveja e execute

Use a mediana do alvo [6, 10, 14] para fixar a previsão constante.

Saída esperada

```text
Referência: 10 min
```
