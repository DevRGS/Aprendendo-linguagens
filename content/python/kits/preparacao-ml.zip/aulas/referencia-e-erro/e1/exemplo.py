from statistics import median

y_treino = [6, 10, 14]
previsao = median(y_treino)
print(f"Referência: {previsao} min")
