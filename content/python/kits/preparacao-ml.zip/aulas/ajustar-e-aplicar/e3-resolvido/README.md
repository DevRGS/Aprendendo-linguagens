# Solução comentada

A troca de km altera apenas o escalado da segunda linha de teste. A min-max do treino pode produzir 2,5 e não recorta valores. Uma coluna constante mapeia todos os valores para zero pela regra explícita. A próxima aula usa o alvo de treino para uma previsão de referência.

Saída esperada

```text
[0.5, 1.5]
[0.5, 2.5]
treino sem km observados
```
