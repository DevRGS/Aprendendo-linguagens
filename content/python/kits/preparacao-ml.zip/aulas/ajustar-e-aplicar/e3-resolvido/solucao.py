import json
import math
from pathlib import Path
from statistics import median

def ajustar(treino):
    observados = [km for km in treino if km is not None]
    if not observados:
        raise ValueError("treino sem km observados")
    return {"mediana": median(observados), "minimo": min(observados), "maximo": max(observados)}

def aplicar(lote, params):
    amplitude = params["maximo"] - params["minimo"]
    preenchidos = [params["mediana"] if km is None else km for km in lote]
    return [(km - params["minimo"]) / amplitude if amplitude else 0.0 for km in preenchidos]

treino = [2, 4, None, 6]
caminho = Path("parametros.json")
caminho.write_text(json.dumps(ajustar(treino), sort_keys=True), encoding="utf-8")
antes = caminho.read_text(encoding="utf-8")
params = json.loads(antes)
print(aplicar([None, 8], params))
print(aplicar([None, 12], params))
assert json.dumps(ajustar(treino), sort_keys=True) == antes
assert caminho.read_text(encoding="utf-8") == antes
assert math.isclose(aplicar([None], params)[0], 0.5, abs_tol=1e-6)
assert aplicar([None, 9], ajustar([4, None, 4])) == [0.0, 0.0]
try:
    ajustar([None])
except ValueError as erro:
    print(erro)
