# E2 · Altere ou depure

A validação é [100, ausente]. Compare preencher com 4, da mediana do treino, e com a mediana local.

Saída esperada

```text
[100, 4]
[100, 100]
```
