from statistics import median

validacao = [100, None]
local = median(km for km in validacao if km is not None)
for valor in (4, local):
    print([valor if km is None else km for km in validacao])
