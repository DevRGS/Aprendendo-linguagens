from statistics import median

treino = [2, 4, None, 6]
observados = [km for km in treino if km is not None]
print(median(observados))
