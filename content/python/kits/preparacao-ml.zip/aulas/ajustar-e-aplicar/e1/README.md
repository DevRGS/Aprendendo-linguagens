# E1 · Preveja e execute

Ache a mediana dos valores observados em [2, 4, ausente, 6].

Saída esperada

```text
4
```
