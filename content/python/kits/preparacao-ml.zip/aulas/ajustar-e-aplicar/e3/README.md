# E3 · Resolva

Implemente ajustar e aplicar separadamente. Salve e recarregue parâmetros de [2,4,ausente,6]. Troque somente um valor de teste e confirme que o JSON guardado se mantém. Cubra amplitude zero e treino todo ausente.

Saída esperada

```text
[0.5, 1.5]
[0.5, 2.5]
treino sem km observados
```
