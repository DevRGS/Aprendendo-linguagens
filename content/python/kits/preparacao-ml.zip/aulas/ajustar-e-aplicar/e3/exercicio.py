from statistics import median

treino = [2, 4, None, 6]
teste = [None, 8]
# Separe o ajuste, a transformação e a persistência dos parâmetros.
