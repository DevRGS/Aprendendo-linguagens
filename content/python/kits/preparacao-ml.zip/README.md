# Python · Preparação para machine learning

Escolha a aula e siga os passos na ordem. Cada pasta corresponde a uma atividade.

1. Abra um terminal na raiz extraída. Cada comando da aula parte dessa raiz.
2. Em `e1`, leia o enunciado e execute o exemplo. Em `e2`, faça a variação.
3. Abra `e3/exercicio.py` num editor de texto, complete a atividade e salve em UTF-8.
4. Depois de testar o seu código, compare com `e3-resolvido/solucao.py` e o README da solução.
5. Volte à central para concluir a aula e revisar com o quiz e os flashcards.

Nos comandos, use o Python 3.14. Confira a versão com `py --version` no Windows ou
`python3 --version` em Linux e macOS. Se apenas `python --version` mostrar o
Python 3.14 no Windows, use `python` no lugar de `py`. Se `python3` apontar
para outra versão, use `python3.14`. O [instalador oficial do Python](https://www.python.org/downloads/)
tem opções por sistema. Reabra o terminal depois de instalar.

## Instale as bibliotecas na raiz extraída

Bash

```bash
python3.14 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s testes
```

Se `python3 --version` já mostrar Python 3.14, você pode usar `python3 -m venv .venv`.
Se sua distribuição não fornecer `venv`, instale o componente da mesma versão
pelo gerenciador de pacotes da distribuição ou consulte o guia de instalação do Python.

PowerShell

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s testes
```

Se `python --version` mostrar Python 3.14 e `py` não estiver disponível,
use `python -m venv .venv`. Use o executável dentro de `.venv` para rodar suas atividades.

As pastas das quatro aulas são

- `aulas/observacao-atributo-alvo/` · Observação, atributos e alvo
- `aulas/particoes/` · Treino, validação e teste
- `aulas/ajustar-e-aplicar/` · Ajustar no treino e aplicar a regra
- `aulas/referencia-e-erro/` · Previsão de referência e MAE
