# E3 · Resolva

Conte linhas com texto em `anotacoes.txt`, que tem uma linha vazia entre duas com texto. Mostre 2. Arquivo vazio ou só com espaços deve dar 0.

Saída esperada

```text
2
```
