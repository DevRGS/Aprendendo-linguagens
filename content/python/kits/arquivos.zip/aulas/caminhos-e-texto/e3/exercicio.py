from pathlib import Path

def contar_com_texto(caminho):
    # Conte as linhas úteis enquanto o arquivo estiver aberto.
    raise NotImplementedError

print(contar_com_texto(Path("anotacoes.txt")))
