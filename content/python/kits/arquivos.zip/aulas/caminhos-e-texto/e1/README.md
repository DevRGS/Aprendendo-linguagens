# E1 · Preveja e execute

Numa pasta temporária da atividade, grave e releia “ação”. Preveja quais caracteres aparecem.

Saída esperada

```text
ação
```
