from pathlib import Path
from tempfile import TemporaryDirectory

with TemporaryDirectory(dir=Path.cwd()) as pasta:
    caminho = Path(pasta) / "mensagem.txt"
    with caminho.open("x", encoding="utf-8") as arquivo:
        arquivo.write("ação")
    with caminho.open("r", encoding="utf-8") as arquivo:
        print(arquivo.read())
