from pathlib import Path

def contar_com_texto(caminho):
    total = 0
    with caminho.open("r", encoding="utf-8") as arquivo:
        for linha in arquivo:
            if linha.strip():
                total += 1
    return total

print(contar_com_texto(Path("anotacoes.txt")))
