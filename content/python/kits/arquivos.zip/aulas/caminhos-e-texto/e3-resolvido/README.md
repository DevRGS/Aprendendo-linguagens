# Solução comentada

A iteração entrega uma linha por vez. strip() retira a quebra e os espaços das extremidades, então uma linha só com espaços deixa uma string vazia. Zero linhas deixa o total em 0.

Saída esperada

```text
2
```
