from pathlib import Path

relativo = Path("mensagem.txt")
absoluto = relativo.resolve()
print(relativo.is_absolute(), absoluto.is_absolute())
print(absoluto.name)
print(absoluto == Path.cwd().resolve() / relativo)
