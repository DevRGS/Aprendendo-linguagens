# E2 · Altere ou depure

Compare o caminho relativo `mensagem.txt` e seu equivalente absoluto. Qual parte é igual nos dois?

Saída esperada

```text
False True
mensagem.txt
True
```
