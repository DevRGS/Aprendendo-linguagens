import json
from pathlib import Path

def resumir(minutos):
    return {"total": sum(minutos), "quantidade": len(minutos)}

caminho = Path("resumo.json")
with caminho.open("w", encoding="utf-8") as arquivo:
    json.dump(resumir([3, 7]), arquivo)
with caminho.open(encoding="utf-8") as arquivo:
    resumo = json.load(arquivo)
print(resumo["total"], resumo["quantidade"])
print(resumo == {"quantidade": 2, "total": 10})
vazio = resumir([])
print(vazio["total"], vazio["quantidade"])
