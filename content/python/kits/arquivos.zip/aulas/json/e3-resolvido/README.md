# Solução comentada

Leia cada campo por nome. A igualdade de dicionários confere os pares independentemente da ordem. A lista vazia tem soma e quantidade iguais a zero.

Saída esperada

```text
10 2
True
0 0
```
