import json

texto = '{"fim": null}'
registro = json.loads(texto)
print(type(texto).__name__, type(registro).__name__)
print("inicio" in registro)
print("fim" in registro, registro["fim"] is None)
