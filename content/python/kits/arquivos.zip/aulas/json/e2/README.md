# E2 · Altere ou depure

Compare o texto `{"fim": null}` e o objeto carregado. Investigue a ausência de `inicio` e a presença de `fim` com valor nulo.

Saída esperada

```text
str dict
False
True True
```
