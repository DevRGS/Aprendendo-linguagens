# E3 · Resolva

Grave `resumo.json` para `[3, 7]` com campos total e quantidade. Releia, mostre `10 2` e confira igualdade com as chaves em ordem inversa. Lista vazia deve resultar em `0 0`.

Saída esperada

```text
10 2
True
0 0
```
