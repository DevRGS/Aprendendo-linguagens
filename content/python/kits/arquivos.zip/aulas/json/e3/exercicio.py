import json
from pathlib import Path

minutos = [3, 7]
caminho = Path("resumo.json")
# Calcule, grave, releia e compare o conteúdo.
