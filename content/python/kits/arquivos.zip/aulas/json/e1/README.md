# E1 · Preveja e execute

Grave um dicionário com uma lista de temas e um campo fim igual a None. Leia o texto e compare o objeto carregado ao original.

Saída esperada

```text
{"temas": ["ação", "dados"], "fim": null}
True
```
