import json
from pathlib import Path

original = {"temas": ["ação", "dados"], "fim": None}
caminho = Path("temas.json")
with caminho.open("w", encoding="utf-8") as arquivo:
    json.dump(original, arquivo, ensure_ascii=False)
print(caminho.read_text(encoding="utf-8"))

with caminho.open(encoding="utf-8") as arquivo:
    recuperado = json.load(arquivo)
print(recuperado == original)
