from pathlib import Path
from csv import DictReader

caminho = Path("pedidos.csv")
with caminho.open(encoding="utf-8", newline="") as arquivo:
    pedido = next(DictReader(arquivo))
    print(pedido["observacao"])

linha = caminho.read_text(encoding="utf-8").splitlines()[1]
print(len(linha.split(",")))
