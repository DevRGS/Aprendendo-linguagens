# E2 · Altere ou depure

Compare a leitura de `01,"fruta, suco"` com a divisão por vírgula. Quantos pedaços o `split` produz para o registro?

Saída esperada

```text
fruta, suco
3
```
