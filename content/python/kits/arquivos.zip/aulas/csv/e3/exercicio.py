from pathlib import Path
from csv import DictReader, DictWriter

origem = Path("sessoes.csv")
destino = Path("selecionadas.csv")
# Escreva o cabeçalho, filtre a origem e releia o destino.
