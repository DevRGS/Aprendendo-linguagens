# E3 · Resolva

Filtre `sessoes.csv` por minutos ≥ 5, grave `selecionadas.csv` com cabeçalho `id,minutos` e releia. Mostre pares com ID como texto e minutos como inteiro. Sem linhas selecionadas, preserve o cabeçalho.

Saída esperada

```text
('02', 7)
('03', 5)
```
