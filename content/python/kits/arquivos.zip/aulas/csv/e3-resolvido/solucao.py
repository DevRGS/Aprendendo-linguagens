from pathlib import Path
from csv import DictReader, DictWriter

destino = Path("selecionadas.csv")
with Path("sessoes.csv").open(encoding="utf-8", newline="") as entrada:
    with destino.open("w", encoding="utf-8", newline="") as saida:
        escritor = DictWriter(saida, fieldnames=["id", "minutos"])
        escritor.writeheader()
        for linha in DictReader(entrada):
            if int(linha["minutos"]) >= 5:
                escritor.writerow(linha)

with destino.open(encoding="utf-8", newline="") as saida:
    for linha in DictReader(saida):
        print((linha["id"], int(linha["minutos"])))
