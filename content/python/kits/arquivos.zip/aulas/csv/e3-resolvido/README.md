# Solução comentada

Escreva o cabeçalho antes do filtro. Converta a duração novamente ao reler. O ID mantém o zero à esquerda. Sem selecionados, o último laço não imprime linhas.

Saída esperada

```text
('02', 7)
('03', 5)
```
