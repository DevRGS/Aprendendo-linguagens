# E1 · Preveja e execute

Leia `sessoes.csv` com cabeçalho `id,minutos` e registros de 3 e 7 minutos. Mostre o tipo de cada campo minutos antes da conversão e o total 10.

Saída esperada

```text
str
str
10
```
