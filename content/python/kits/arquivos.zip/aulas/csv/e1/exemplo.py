from pathlib import Path
from csv import DictReader

with Path("sessoes.csv").open(encoding="utf-8", newline="") as arquivo:
    total = 0
    for linha in DictReader(arquivo):
        print(type(linha["minutos"]).__name__)
        total += int(linha["minutos"])
print(total)
