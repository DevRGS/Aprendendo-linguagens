# E2 · Altere ou depure

Compare um arquivo ausente e outro com a segunda linha inválida. Mostre o número da linha e confira a causa original.

Saída esperada

```text
arquivo ausente
linha 2: inteiro inválido
causa: ValueError
```
