from pathlib import Path

def ler_total(caminho):
    total = 0
    with caminho.open(encoding="utf-8") as arquivo:
        for numero, linha in enumerate(arquivo, start=1):
            try:
                total += int(linha)
            except ValueError as erro:
                raise ValueError(f"linha {numero}: inteiro inválido") from erro
    return total

for nome in ["sem-medidas.txt", "medidas.txt"]:
    try:
        print(ler_total(Path(nome)))
    except FileNotFoundError:
        print("arquivo ausente")
    except ValueError as erro:
        print(erro)
        print(f"causa: {type(erro.__cause__).__name__}")
