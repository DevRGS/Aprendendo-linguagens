# E1 · Preveja e execute

Tente converter “dez” em inteiro. Capture a exceção ValueError esperada e explique a causa.

Saída esperada

```text
ValueError: inteiro inválido
```
