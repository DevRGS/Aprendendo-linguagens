texto = "dez"
try:
    valor = int(texto)
except ValueError:
    print("ValueError: inteiro inválido")
