from pathlib import Path

def resumir_lote(caminho):
    validos = rejeitados = soma = 0
    # Leia linha a linha, converta e atualize os três acumuladores.
    raise NotImplementedError

print(resumir_lote(Path("lote.txt")))
