# E3 · Resolva

Leia `lote.txt` com `3`, `erro` e `0` em três linhas. Pule somente conversões inválidas. Mostre dois válidos, uma rejeição e soma 3. Um arquivo vazio deve dar três zeros.

Saída esperada

```text
válidos=2, rejeitados=1, soma=3
```
