# Solução comentada

Toda conversão bem-sucedida conta, inclusive zero. Linha em branco é rejeitada por int. No arquivo vazio o laço não roda. Erro ao abrir se propaga.

Saída esperada

```text
válidos=2, rejeitados=1, soma=3
```
