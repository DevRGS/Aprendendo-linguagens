from pathlib import Path

def resumir_lote(caminho):
    validos = rejeitados = soma = 0
    with caminho.open(encoding="utf-8") as arquivo:
        for linha in arquivo:
            try:
                numero = int(linha)
            except ValueError:
                rejeitados += 1
                continue
            validos += 1
            soma += numero
    return validos, rejeitados, soma

validos, rejeitados, soma = resumir_lote(Path("lote.txt"))
print(f"válidos={validos}, rejeitados={rejeitados}, soma={soma}")
