# E3 · Resolva

Decore `etiqueta` para contar duas chamadas e preserve seus retornos e nome. Use um contador por função decorada. Antes da primeira chamada, a contagem deve ser zero.

Saída esperada

```text
0
ID: a
Lote: b
etiqueta 2
```
