from functools import wraps

def contar(funcao):
    @wraps(funcao)
    def wrapper(*args, **kwargs):
        # Conte a tentativa e devolva o resultado original.
        raise NotImplementedError

    # Inicialize o contador no wrapper antes de devolvê-lo.
    return wrapper
