# Solução comentada

Cada aplicação cria um wrapper com seu contador. wraps mantém o nome e return preserva o resultado. A contagem é incrementada antes de executar, então uma chamada que falhe também conta como tentativa.

Saída esperada

```text
0
ID: a
Lote: b
etiqueta 2
```
