from functools import wraps

def contar(funcao):
    @wraps(funcao)
    def wrapper(*args, **kwargs):
        wrapper.chamadas += 1
        return funcao(*args, **kwargs)

    wrapper.chamadas = 0
    return wrapper

@contar
def etiqueta(texto, prefixo="ID"):
    return f"{prefixo}: {texto}"

print(etiqueta.chamadas)
print(etiqueta("a"))
print(etiqueta("b", prefixo="Lote"))
print(etiqueta.__name__, etiqueta.chamadas)
