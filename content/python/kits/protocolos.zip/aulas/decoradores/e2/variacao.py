def defeituoso(funcao):
    def wrapper(*args):
        funcao(*args)
    return wrapper

def corrigido(funcao):
    def wrapper(*args, **kwargs):
        return funcao(*args, **kwargs)
    return wrapper

def somar(a, b=0):
    return a + b

ruim = defeituoso(somar)
print(ruim(2, 3))
try:
    ruim(2, b=3)
except TypeError:
    print("argumento nomeado rejeitado")

bom = corrigido(somar)
print(bom(2, b=3))
