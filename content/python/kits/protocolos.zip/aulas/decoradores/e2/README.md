# E2 · Altere ou depure

Investigue o wrapper que perde o retorno e não aceita argumento nomeado. Capture o TypeError intencional e compare com o wrapper reparado.

Saída esperada

```text
None
argumento nomeado rejeitado
5
```
