# E1 · Preveja e execute

Envolva uma função dobro, registre uma chamada e confira se o registro aparece antes ou depois do resultado.

Saída esperada

```text
chamada registrada
6
```
