def registrar(funcao):
    def wrapper(valor):
        print("chamada registrada")
        return funcao(valor)
    return wrapper

@registrar
def dobro(n):
    return n * 2

print(dobro(3))
