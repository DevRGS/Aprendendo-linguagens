# E1 · Preveja e execute

Gere os quadrados dos inteiros 0, 1 e 2. Antes do laço, diga em que momento a função geradora calculará cada item.

Saída esperada

```text
0
1
4
```
