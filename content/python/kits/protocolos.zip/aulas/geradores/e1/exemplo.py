def quadrados(limite):
    for n in range(limite):
        yield n * n

for valor in quadrados(3):
    print(valor)
