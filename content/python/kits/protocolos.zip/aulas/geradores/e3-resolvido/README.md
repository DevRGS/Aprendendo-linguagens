# Solução comentada

O gerador lê uma linha de cada vez, e sum consome até o fim sem montar uma lista. O arquivo fica aberto no with durante o consumo e fecha ao encerrar. Sem valores, sum começa e termina em zero.

Saída esperada

```text
6
0
```
