from pathlib import Path

def inteiros(caminho):
    with caminho.open(encoding="utf-8") as arquivo:
        for linha in arquivo:
            try:
                numero = int(linha)
            except ValueError:
                continue
            yield numero

print(sum(inteiros(Path("leituras.txt"))))
print(sum(inteiros(Path("vazio.txt"))))
