# E3 · Resolva

Some os inteiros de `leituras.txt` sem armazenar todas as linhas. Pule linhas sem inteiro, aceite zero e negativos e faça a soma de arquivo vazio resultar em 0. No arquivo fornecido, espere 6.

Saída esperada

```text
6
0
```
