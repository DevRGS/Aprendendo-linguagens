from pathlib import Path

def inteiros(caminho):
    # Use with, percorra as linhas e emita inteiros com yield.
    raise NotImplementedError

print(sum(inteiros(Path("leituras.txt"))))
