# E2 · Altere ou depure

Acrescente uma marca antes de yield. Crie um gerador e consuma apenas o primeiro valor. Conte as marcas produzidas.

Saída esperada

```text
gerador criado
calculando 0
primeiro: 0
```
