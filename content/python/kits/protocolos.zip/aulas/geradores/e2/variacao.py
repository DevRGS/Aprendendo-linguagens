def quadrados(limite):
    for n in range(limite):
        print(f"calculando {n}")
        yield n * n

cursor = quadrados(3)
print("gerador criado")
print("primeiro:", next(cursor))
