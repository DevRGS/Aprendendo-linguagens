from pathlib import Path

with Path("amostra.txt").open(encoding="utf-8") as arquivo:
    print(arquivo.read().strip())
    print(arquivo.closed)
print(arquivo.closed)
