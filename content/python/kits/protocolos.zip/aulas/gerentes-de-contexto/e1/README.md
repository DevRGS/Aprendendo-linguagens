# E1 · Preveja e execute

Leia `amostra.txt` e imprima `arquivo.closed` dentro e fora de with. Preveja as duas respostas.

Saída esperada

```text
sessão
False
True
```
