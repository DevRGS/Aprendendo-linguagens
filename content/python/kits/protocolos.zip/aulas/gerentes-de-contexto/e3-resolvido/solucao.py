from contextlib import contextmanager

@contextmanager
def registrar(eventos):
    eventos.append("início")
    try:
        yield
    finally:
        eventos.append("fim")

normal = []
with registrar(normal):
    normal.append("trabalho")
print(" / ".join(normal))

com_erro = []
falha = ValueError("dado inválido")
try:
    with registrar(com_erro):
        raise falha
except ValueError as observada:
    print(" / ".join(com_erro))
    print("mesma exceção:", observada is falha)
