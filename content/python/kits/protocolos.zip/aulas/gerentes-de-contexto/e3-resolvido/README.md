# Solução comentada

A entrada registra início. Durante yield, o bloco do with roda. finally executa a limpeza nas duas saídas. Como o gerente não captura o erro, ele se propaga para o tratamento externo.

Saída esperada

```text
início / trabalho / fim
início / fim
mesma exceção: True
```
