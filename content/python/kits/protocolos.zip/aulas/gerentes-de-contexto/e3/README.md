# E3 · Resolva

Implemente um contexto que registre início e fim. Faça uma execução normal e outra que levante ValueError no bloco. Registre o fim em ambos os casos e confirme que a exceção observada fora é a original.

Saída esperada

```text
início / trabalho / fim
início / fim
mesma exceção: True
```
