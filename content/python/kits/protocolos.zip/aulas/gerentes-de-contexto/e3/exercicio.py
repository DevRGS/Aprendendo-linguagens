from contextlib import contextmanager

@contextmanager
def registrar(eventos):
    eventos.append("início")
    # Suspenda durante o bloco e registre o fim na saída.
    raise NotImplementedError

eventos = []
# Teste saídas normal e por ValueError.
