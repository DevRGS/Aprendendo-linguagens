from pathlib import Path

try:
    with Path("amostra.txt").open(encoding="utf-8") as arquivo:
        print(arquivo.read().strip())
        raise ValueError("dado inválido")
except ValueError as erro:
    print(erro)
    print("fechado:", arquivo.closed)
