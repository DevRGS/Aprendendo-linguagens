# E2 · Altere ou depure

Levante ValueError intencional dentro do bloco após ler `amostra.txt`. Capture fora e verifique se o arquivo já está fechado.

Saída esperada

```text
sessão
dado inválido
fechado: True
```
