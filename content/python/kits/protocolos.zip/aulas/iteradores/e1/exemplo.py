cursor = iter([2, 5])
print(next(cursor))
print(next(cursor))
try:
    next(cursor)
except StopIteration:
    print("fim do iterador")
