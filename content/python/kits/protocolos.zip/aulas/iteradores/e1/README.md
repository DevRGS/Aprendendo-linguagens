# E1 · Preveja e execute

Consuma [2, 5] com duas chamadas. Faça uma terceira chamada intencionalmente e capture apenas StopIteration.

Saída esperada

```text
2
5
fim do iterador
```
