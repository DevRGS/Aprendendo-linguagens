def primeiro_valido(registros):
    candidatos = (n for n in registros if type(n) is int and n >= 0)
    # Consuma só o primeiro e informe o que fazer no esgotamento.
    raise NotImplementedError

print(primeiro_valido([None, -1, 0, 4]))
print(primeiro_valido([]))
