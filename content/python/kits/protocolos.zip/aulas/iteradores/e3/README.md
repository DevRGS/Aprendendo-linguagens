# E3 · Resolva

Obtenha apenas o primeiro inteiro não negativo em [None, -1, 0, 4]. Use None como padrão para uma entrada sem válidos, inclusive a sequência vazia.

Saída esperada

```text
0
None
None
```
