def primeiro_valido(registros):
    validos = (n for n in registros if type(n) is int and n >= 0)
    return next(validos, None)

print(primeiro_valido([None, -1, 0, 4]))
print(primeiro_valido([None, -2]))
print(primeiro_valido([]))
