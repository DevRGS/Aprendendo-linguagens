# Solução comentada

A expressão com parênteses produz os candidatos sob demanda. next só pede um. type(n) is int restringe a inteiros, excluindo bool, e a segunda condição aceita 0. None identifica esgotamento sem ser uma resposta válida.

Saída esperada

```text
0
None
None
```
