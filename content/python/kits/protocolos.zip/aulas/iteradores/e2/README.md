# E2 · Altere ou depure

Faça dois percursos de uma lista e dois do mesmo iterador. Preveja o segundo resultado de cada um.

Saída esperada

```text
[2, 5] [2, 5]
[2, 5] []
```
