valores = [2, 5]
print([n for n in valores], [n for n in valores])

cursor = iter(valores)
print(list(cursor), list(cursor))
