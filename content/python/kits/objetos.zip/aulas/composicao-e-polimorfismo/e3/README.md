# E3 · Resolva

Construa Processador que recebe uma estratégia no inicializador e processa uma lista de rótulos. Teste Normalizar e Identidade com [" Azul ", "VERDE"]. As saídas devem manter ordem e quantidade. Entrada vazia deve produzir lista vazia.

Saída esperada

```text
['azul', 'verde']
[' Azul ', 'VERDE']
[]
```
