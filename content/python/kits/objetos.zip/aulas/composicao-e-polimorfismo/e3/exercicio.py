class Normalizar:
    def transformar(self, texto):
        return texto.strip().lower()


class Identidade:
    def transformar(self, texto):
        return texto


class Processador:
    def __init__(self, estrategia):
        self.estrategia = estrategia

    def processar(self, rotulos):
        # Devolva uma nova lista na ordem da entrada.
        raise NotImplementedError
