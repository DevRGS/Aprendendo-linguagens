# E2 · Altere ou depure

Troque a normalização pela identidade ao chamar rotular. Antes de rodar, diga onde os espaços aparecerão entre os delimitadores.

Saída esperada

```text
[leitura]
[ Leitura ]
```
