class Normalizar:
    def transformar(self, texto):
        return texto.strip().lower()


class Identidade:
    def transformar(self, texto):
        return texto


def rotular(texto, estrategia):
    return "[" + estrategia.transformar(texto) + "]"

texto = " Leitura "
print(rotular(texto, Normalizar()))
print(rotular(texto, Identidade()))
