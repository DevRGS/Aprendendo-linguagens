# Solução comentada

O processador guarda a estratégia recebida e aplica seu método a cada entrada na ordem. A compreensão cria nova lista e, se a entrada estiver vazia, não chama a estratégia.

Saída esperada

```text
['azul', 'verde']
[' Azul ', 'VERDE']
[]
```
