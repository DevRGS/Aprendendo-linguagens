class Normalizar:
    def transformar(self, texto):
        return texto.strip().lower()


class Identidade:
    def transformar(self, texto):
        return texto


class Processador:
    def __init__(self, estrategia):
        self.estrategia = estrategia

    def processar(self, rotulos):
        return [self.estrategia.transformar(rotulo) for rotulo in rotulos]


rotulos = [" Azul ", "VERDE"]
normalizador = Processador(Normalizar())
identidade = Processador(Identidade())
print(normalizador.processar(rotulos))
print(identidade.processar(rotulos))
print(normalizador.processar([]))
