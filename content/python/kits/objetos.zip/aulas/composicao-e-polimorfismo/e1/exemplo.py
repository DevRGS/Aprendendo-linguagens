class Normalizar:
    def transformar(self, texto):
        return texto.strip().lower()


class Identidade:
    def transformar(self, texto):
        return texto


for estrategia in [Normalizar(), Identidade()]:
    print(repr(estrategia.transformar(" Azul ")))
