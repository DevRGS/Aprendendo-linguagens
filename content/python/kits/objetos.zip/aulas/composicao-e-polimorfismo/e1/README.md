# E1 · Preveja e execute

As duas estratégias têm o mesmo método. Aplique ambas a " Azul " e mostre onde ficaram os espaços.

Saída esperada

```text
'azul'
' Azul '
```
