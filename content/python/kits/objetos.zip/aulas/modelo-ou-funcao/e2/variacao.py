class Coleta:
    def __init__(self):
        self.total = 0

    def registrar(self, valor):
        self.total += valor


compartilhada = Coleta()
compartilhada.registrar(2)
compartilhada.registrar(5)
print(compartilhada.total)

lote_a, lote_b = Coleta(), Coleta()
lote_a.registrar(2)
lote_b.registrar(5)
print(lote_a.total, lote_b.total)
