# E2 · Altere ou depure

Simule dois lotes de uma coleta incremental. Observe o que acontece ao reutilizar a instância e depois confira o total com instâncias independentes.

Saída esperada

```text
7
2 5
```
