# E1 · Preveja e execute

Reescreva um resumo sem estado como função pura. Compare seu retorno com o da classe e confira se a lista original mudou.

Saída esperada

```text
True
[2, 5]
```
