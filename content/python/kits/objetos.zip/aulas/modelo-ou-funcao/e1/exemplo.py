class Calculadora:
    def resumo(self, medidas):
        return {"total": sum(medidas), "quantidade": len(medidas)}


def resumir(medidas):
    return {"total": sum(medidas), "quantidade": len(medidas)}

medidas = [2, 5]
print(resumir(medidas) == Calculadora().resumo(medidas))
print(medidas)
