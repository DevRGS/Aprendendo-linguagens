def relatorio(medidas):
    # Devolva os campos total e quantidade.
    raise NotImplementedError

assert relatorio([2, 5]) == {"total": 7, "quantidade": 2}
# Inclua testes de zero, lista vazia e repetição.
