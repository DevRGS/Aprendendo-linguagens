# E3 · Resolva

Entregue uma função relatorio(medidas) que devolva total e quantidade para uma lista entregue de uma vez. Teste [2, 5], [0] e []. Mostre que chamá-la duas vezes não acumula estado. Justifique a escolha de função ou objeto.

Saída esperada

```text
{'total': 7, 'quantidade': 2}
quatro verificações passaram
```
