# Solução comentada

A lista completa chega como argumento. Uma função basta, pois cada resultado depende só daquela lista. Zero entra na quantidade. A lista vazia tem total e quantidade 0. As condições de assert verificam resultados previstos independentemente.

Saída esperada

```text
{'total': 7, 'quantidade': 2}
quatro verificações passaram
```
