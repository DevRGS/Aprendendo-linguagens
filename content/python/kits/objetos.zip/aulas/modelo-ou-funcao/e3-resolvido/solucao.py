def relatorio(medidas):
    return {"total": sum(medidas), "quantidade": len(medidas)}

normal = relatorio([2, 5])
assert normal == {"total": 7, "quantidade": 2}
assert relatorio([0]) == {"total": 0, "quantidade": 1}
assert relatorio([]) == {"total": 0, "quantidade": 0}
assert relatorio([2, 5]) == normal
print(normal)
print("quatro verificações passaram")
