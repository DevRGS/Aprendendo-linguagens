class Contador:
    def __init__(self):
        self.valor = 0

    def incrementar(self):
        self.valor += 1


a, b = Contador(), Contador()
print(a.valor, b.valor)
a.incrementar()
print(a.valor, b.valor)
