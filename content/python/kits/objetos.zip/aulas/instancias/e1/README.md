# E1 · Preveja e execute

Crie e exiba dois contadores, incremente apenas o primeiro e observe os dois estados finais.

Saída esperada

```text
0 0
1 0
```
