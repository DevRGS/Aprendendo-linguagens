class Acumulador:
    def __init__(self):
        self.total = 0

    def adicionar(self, valor):
        self.total += valor


acumulador = Acumulador()
acumulador.adicionar(2)
acumulador.adicionar(5)
print(acumulador.total)

vazio = Acumulador()
vazio.adicionar(0)
print(vazio.total)
