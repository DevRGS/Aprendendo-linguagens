# Solução comentada

O total fica na instância. Cada método adiciona ao valor anterior. Acrescentar zero preserva o total e outra instância começa do próprio zero.

Saída esperada

```text
7
0
```
