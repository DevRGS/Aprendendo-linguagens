# E3 · Resolva

Implemente Acumulador com total inicial 0 e um método adicionar. Adicione 2 e 5 à primeira instância e exiba 7. Uma instância nova ou que recebeu apenas 0 deve expor total 0.

Saída esperada

```text
7
0
```
