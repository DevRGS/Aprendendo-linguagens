class Acumulador:
    def __init__(self):
        # Defina o estado inicial desta instância.
        raise NotImplementedError

    def adicionar(self, valor):
        raise NotImplementedError


acumulador = Acumulador()
# Adicione 2 e 5 e imprima o total.
