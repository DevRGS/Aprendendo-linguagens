# E2 · Altere ou depure

Em `AgendaCompartilhada`, acrescente "coleta" pela primeira instância e consulte a segunda. Depois teste uma lista inicializada por instância.

Saída esperada

```text
['coleta']
[]
```
