class AgendaCompartilhada:
    tarefas = []


class AgendaIndividual:
    def __init__(self):
        self.tarefas = []


a, b = AgendaCompartilhada(), AgendaCompartilhada()
a.tarefas.append("coleta")
print(b.tarefas)

c, d = AgendaIndividual(), AgendaIndividual()
c.tarefas.append("coleta")
print(d.tarefas)
