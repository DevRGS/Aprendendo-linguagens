# E2 · Altere ou depure

Guarde uma lista de marcas em cada medição. Adicione uma marca só à primeira e preveja a segunda lista.

Saída esperada

```text
['revista'] []
```
