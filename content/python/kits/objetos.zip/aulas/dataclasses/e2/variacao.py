from dataclasses import dataclass, field

@dataclass
class Medicao:
    id: str
    marcas: list[str] = field(default_factory=list)

a = Medicao("a")
b = Medicao("b")
a.marcas.append("revista")
print(a.marcas, b.marcas)
