from dataclasses import dataclass

@dataclass
class Medida:
    id: str
    valor: float

a = Medida("007", 3.5)
b = Medida("007", 3.5)
print(a == b, a is b)
