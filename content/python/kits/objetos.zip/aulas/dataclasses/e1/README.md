# E1 · Preveja e execute

Defina Medida(id, valor) e crie dois registros iguais. Compare igualdade por conteúdo e identidade.

Saída esperada

```text
True False
```
