# Solução comentada

O CSV fornece campos de texto. float converte valor e rejeita texto não numérico. isfinite rejeita NaN e infinitos, que float aceita. Zero é válido e o ID conserva os zeros iniciais.

Saída esperada

```text
001 3.5
002 0.0
rejeitado: valor deve ser finito
```
