import csv
from dataclasses import dataclass
from math import isfinite
from pathlib import Path

@dataclass
class Medida:
    id: str
    valor: float

def converter(linha):
    valor = float(linha["valor"])
    if not isfinite(valor):
        raise ValueError("valor deve ser finito")
    return Medida(linha["id"], valor)

with Path("medicoes.csv").open(encoding="utf-8", newline="") as arquivo:
    medidas = [converter(linha) for linha in csv.DictReader(arquivo)]
for medida in medidas:
    print(medida.id, medida.valor)

try:
    converter({"id": "003", "valor": "NaN"})
except ValueError as erro:
    print(f"rejeitado: {erro}")
