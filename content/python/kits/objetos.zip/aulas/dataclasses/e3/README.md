# E3 · Resolva

Leia `medicoes.csv` e converta seus dois registros em Medida. Mantenha ID textual e aceite apenas valores numéricos finitos. Mostre cada ID e valor. Pela mesma função, teste e capture `ValueError` para uma linha com valor inválido.

Saída esperada

```text
001 3.5
002 0.0
rejeitado: valor deve ser finito
```
