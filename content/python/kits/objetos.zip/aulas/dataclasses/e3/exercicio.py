import csv
from dataclasses import dataclass
from math import isfinite
from pathlib import Path

@dataclass
class Medida:
    id: str
    valor: float

def converter(linha):
    # Converta e valide valor, preserve id e crie a Medida.
    raise NotImplementedError

with Path("medicoes.csv").open(encoding="utf-8", newline="") as arquivo:
    medidas = [converter(linha) for linha in csv.DictReader(arquivo)]
print(medidas)
