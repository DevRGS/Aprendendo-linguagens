# E2 · Altere ou depure

Inclua também a:3. Remova cópias exatas apenas numa tabela temporária. Aponte os IDs conflitantes.

Saída esperada

```text
['a']
```
