import pandas as pd

df = pd.DataFrame({"id": ["a", "b", "a", "a"], "km": [0, None, 0, 3]})
unicas = df.drop_duplicates()
conflitos = unicas.loc[unicas["id"].duplicated(keep=False), "id"].unique()
print(conflitos.tolist())
