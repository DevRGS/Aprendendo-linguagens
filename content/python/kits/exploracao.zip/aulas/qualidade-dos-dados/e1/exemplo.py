import pandas as pd

df = pd.DataFrame({"id": ["a", "b", "a"], "km": [0, None, 0]})
print("Ausentes:", df.loc[df["km"].isna(), "id"].tolist())
print("Zeros:", df.loc[df["km"].eq(0), "id"].tolist())
print("Duplicatas excedentes:", df.loc[df.duplicated(), "id"].tolist())
