# E1 · Preveja e execute

Examine as linhas a:0, b:ausente, a:0. Liste IDs com ausência, com zero e de ocorrências repetidas.

Saída esperada

```text
Ausentes: ['b']
Zeros: ['a', 'a']
Duplicatas excedentes: ['a']
```
