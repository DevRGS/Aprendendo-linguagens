import pandas as pd

df = pd.DataFrame({"id": ["a", "b", "c", "a", "a"], "km": [0, None, -2, 0, 1]})
# Monte uma lista de IDs por regra.
