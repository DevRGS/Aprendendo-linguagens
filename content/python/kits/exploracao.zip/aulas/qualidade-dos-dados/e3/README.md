# E3 · Resolva

Audite ausências, negativos, duplicatas excedentes e conflitos de ID sem alterar o original. Use a:0, b:ausente, c:-2, a:0 e a:1. No caso de borda c:-2, mantenha a linha disponível para inspeção e só liste no relatório.

Saída esperada

```text
km ausentes 1 ['b']
km negativos 1 ['c']
duplicatas excedentes 1 ['a']
IDs em conflito 1 ['a']
```
