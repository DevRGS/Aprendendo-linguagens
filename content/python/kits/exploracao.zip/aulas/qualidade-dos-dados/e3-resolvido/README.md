# Solução comentada

As três primeiras medidas contam linhas brutas. A quarta conta chaves distintas em conflito. A própria tabela permanece disponível para decidir o destino de cada linha. Com a qualidade descrita, avance para distribuições.

Saída esperada

```text
km ausentes 1 ['b']
km negativos 1 ['c']
duplicatas excedentes 1 ['a']
IDs em conflito 1 ['a']
```
