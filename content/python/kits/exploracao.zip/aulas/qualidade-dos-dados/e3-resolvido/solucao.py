import pandas as pd

def auditar(df):
    unicas = df.drop_duplicates()
    conflitos = unicas.loc[unicas["id"].duplicated(keep=False), "id"].unique()
    return {
        "km ausentes": df.loc[df["km"].isna(), "id"].tolist(),
        "km negativos": df.loc[df["km"].lt(0), "id"].tolist(),
        "duplicatas excedentes": df.loc[df.duplicated(), "id"].tolist(),
        "IDs em conflito": sorted(conflitos.tolist()),
    }

df = pd.DataFrame({"id": ["a", "b", "c", "a", "a"], "km": [0, None, -2, 0, 1]})
for regra, ids in auditar(df).items():
    print(regra, len(ids), ids)
assert len(df) == 5
assert df.loc[2, "km"] == -2
