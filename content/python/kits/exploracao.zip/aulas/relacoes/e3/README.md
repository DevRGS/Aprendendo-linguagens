# E3 · Resolva

Compare pontos de dois sensores fictícios nos ajustes [-2,-1,0,1,2]. O sensor 1 lê o próprio ajuste e o sensor 2 lê seu quadrado. Salve dois gráficos com unidades arbitrárias, liste os pares e explique o caso de borda de variáveis relacionadas com r igual a zero.

Saída esperada

```text
Reta: r = 1.0 [(-2, -2), (-1, -1), (0, 0), (1, 1), (2, 2)]
Curva: r = 0.0 [(-2, 4), (-1, 1), (0, 0), (1, 1), (2, 4)]
```
