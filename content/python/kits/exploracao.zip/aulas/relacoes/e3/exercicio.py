import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

x = np.array([-2, -1, 0, 1, 2])
# Compare x com x e com x**2 usando dois gráficos de dispersão.
