# E2 · Altere ou depure

Troque y por [4, 4, 4]. Detecte desvio zero antes de calcular e apresente o estado do coeficiente.

Saída esperada

```text
r indefinido
```
