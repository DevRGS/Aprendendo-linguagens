import numpy as np

x = [1, 2, 3]
y = [4, 4, 4]
if np.std(x) == 0 or np.std(y) == 0:
    print("r indefinido")
else:
    print(np.corrcoef(x, y)[0, 1])
