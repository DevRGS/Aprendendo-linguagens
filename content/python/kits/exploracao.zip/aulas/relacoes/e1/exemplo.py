import numpy as np

x = [1, 2, 3]
y = [2, 4, 6]
print(f"r = {np.corrcoef(x, y)[0, 1]:.1f}")
