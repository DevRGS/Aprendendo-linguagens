# E1 · Preveja e execute

Acople [1, 2, 3] km a [2, 4, 6] min e calcule a correlação linear. Preveja o sinal.

Saída esperada

```text
r = 1.0
```
