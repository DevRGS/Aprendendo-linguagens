import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

x = np.array([-2, -1, 0, 1, 2])
fig, axes = plt.subplots(1, 2, layout="constrained")
for ax, y, titulo in zip(axes, [x, x**2], ["Reta", "Curva"], strict=True):
    r = np.corrcoef(x, y)[0, 1]
    print(f"{titulo}: r = {r:.1f}", list(zip(x.tolist(), y.tolist(), strict=True)))
    ax.scatter(x, y, marker="o", edgecolors="black")
    ax.set(xlabel="Ajuste (u.a.)", ylabel="Leitura (u.a.)", title=titulo)
fig.savefig("relacoes.png")
plt.close(fig)
assert np.isclose(np.corrcoef(x, x**2)[0, 1], 0, atol=1e-9)
