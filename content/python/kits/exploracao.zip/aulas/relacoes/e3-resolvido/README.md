# Solução comentada

Na figura da esquerda os pontos formam uma reta crescente. À direita formam um U simétrico, com correlação linear zero e relação matemática exata. Os pares escritos permitem reconstruir os gráficos. Em dados observacionais, mesmo r alto pode refletir um terceiro fator. A próxima aula liga o gráfico à pergunta.

Saída esperada

```text
Reta: r = 1.0 [(-2, -2), (-1, -1), (0, 0), (1, 1), (2, 2)]
Curva: r = 0.0 [(-2, 4), (-1, 1), (0, 0), (1, 1), (2, 4)]
```
