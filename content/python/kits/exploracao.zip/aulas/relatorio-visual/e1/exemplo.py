import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

fig, ax = plt.subplots(layout="constrained")
ax.bar(["A", "B"], [3, 4], edgecolor="black")
ax.set(xlabel="Estação", ylabel="Viagens pontuais (contagem)", title="Registros pontuais")
fig.savefig("pontuais.png")
plt.close(fig)
print("A: 3 viagens; B: 4 viagens")
