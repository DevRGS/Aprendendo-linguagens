# E1 · Preveja e execute

Crie uma figura de barras de viagens pontuais por estação, A=3 e B=4. Rotule o eixo e salve o PNG.

Saída esperada

```text
A: 3 viagens; B: 4 viagens
```
