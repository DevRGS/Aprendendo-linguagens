# E2 · Altere ou depure

O rótulo de porcentagem seria incorreto sobre barras de alturas 3 e 4. Use totais 4 e 8 para calcular porcentagens e salve as barras corrigidas.

Saída esperada

```text
A: 75% de 4; B: 50% de 8
```
