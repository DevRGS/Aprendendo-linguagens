import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

estacoes, pontuais, totais = ["A", "B"], [3, 4], [4, 8]
percentuais = [100 * pontos / total for pontos, total in zip(pontuais, totais, strict=True)]
fig, ax = plt.subplots(layout="constrained")
ax.bar(estacoes, percentuais, edgecolor="black")
ax.set(xlabel="Estação", ylabel="Viagens pontuais (%)", ylim=(0, 100), title="Pontualidade")
fig.savefig("percentuais.png")
plt.close(fig)
print("A: 75% de 4; B: 50% de 8")
