import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

dados = [("A", 3, 4), ("B", 4, 8), ("C", 0, 0)]
# Prepare a tabela e passe só percentuais definidos ao gráfico.
