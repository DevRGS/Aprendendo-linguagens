# E3 · Resolva

Para A=3/4, B=4/8 e C=0/0, entregue uma figura com percentuais definidos, tabela com numeradores e denominadores e duas frases sustentadas pelos números. Marque C como não calculável.

Saída esperada

```text
Estação | Pontuais | Total | Percentual
A | 3 | 4 | 75%
B | 4 | 8 | 50%
C | 0 | 0 | não calculável
A teve 75% e B teve 50% de pontualidade na amostra.
C não teve viagens registradas, então não há taxa para comparar.
```
