# Solução comentada

As barras de A e B têm alturas de 75% e 50%. C permanece na tabela com denominador zero. Com poucos registros, os percentuais descrevem esta amostra. Na preparação para ML, decida quais dados estarão disponíveis antes da previsão.

Saída esperada

```text
Estação | Pontuais | Total | Percentual
A | 3 | 4 | 75%
B | 4 | 8 | 50%
C | 0 | 0 | não calculável
A teve 75% e B teve 50% de pontualidade na amostra.
C não teve viagens registradas, então não há taxa para comparar.
```
