import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

dados = [("A", 3, 4), ("B", 4, 8), ("C", 0, 0)]
nomes, alturas = [], []
print("Estação | Pontuais | Total | Percentual")
for nome, pontuais, total in dados:
    if total == 0:
        print(f"{nome} | {pontuais} | {total} | não calculável")
    else:
        percentual = 100 * pontuais / total
        nomes.append(nome)
        alturas.append(percentual)
        print(f"{nome} | {pontuais} | {total} | {percentual:.0f}%")

fig, ax = plt.subplots(layout="constrained")
ax.bar(nomes, alturas, edgecolor="black")
ax.set(xlabel="Estação", ylabel="Viagens pontuais (%)", ylim=(0, 100),
       title="Pontualidade entre estações observadas")
fig.savefig("relatorio.png")
plt.close(fig)
print("A teve 75% e B teve 50% de pontualidade na amostra.")
print("C não teve viagens registradas, então não há taxa para comparar.")
