# E2 · Altere ou depure

Para os mesmos tempos, compare as contagens com bordas [0,4,8] e [0,2,4,6,8]. Explique por que o valor máximo entra no último intervalo.

Saída esperada

```text
[0, 4, 8] [2, 3]
[0, 2, 4, 6, 8] [1, 1, 1, 2]
```
