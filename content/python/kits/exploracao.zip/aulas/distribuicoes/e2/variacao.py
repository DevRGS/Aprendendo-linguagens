import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

tempos = [0, 2, 4, 6, 8]
fig, axes = plt.subplots(1, 2, sharey=True, layout="constrained")
for ax, bordas in zip(axes, [[0, 4, 8], [0, 2, 4, 6, 8]], strict=True):
    contagens, _, _ = ax.hist(tempos, bins=bordas, edgecolor="black")
    ax.set(xlabel="Tempo (min)", ylabel="Viagens (contagem)", title=f"{len(bordas) - 1} intervalos")
    print(bordas, contagens.astype(int).tolist())
fig.savefig("intervalos.png")
plt.close(fig)
