# E3 · Resolva

Para [1, 2, 2, 3, 9] minutos, entregue mediana, amplitude interquartil e um histograma com bordas [0, 3, 6, 9] e eixos com unidades. Mostre também que uma amostra constante [2, 2] tem amplitude interquartil zero.

Saída esperada

```text
Mediana: 2.0 min. AIQ: 1.0 min.
Contagens: [3, 1, 1]
```
