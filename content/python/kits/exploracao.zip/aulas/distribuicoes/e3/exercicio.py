import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

tempos = [1, 2, 2, 3, 9]
bordas = [0, 3, 6, 9]
# Calcule os quartis e salve a figura.
