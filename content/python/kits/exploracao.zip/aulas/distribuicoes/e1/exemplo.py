import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

tempos = [0, 2, 4, 6, 8]
print(np.quantile(tempos, [0.25, 0.50, 0.75], method="linear").tolist())
fig, ax = plt.subplots(layout="constrained")
contagens, _, _ = ax.hist(tempos, bins=[0, 4, 8], edgecolor="black")
ax.set(xlabel="Tempo (min)", ylabel="Viagens (contagem)", title="Distribuição de tempos")
fig.savefig("quartis.png")
plt.close(fig)
print(contagens.astype(int).tolist())
