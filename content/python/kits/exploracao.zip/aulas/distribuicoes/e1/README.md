# E1 · Preveja e execute

Calcule os quartis de [0, 2, 4, 6, 8]. Salve o histograma com intervalos [0, 4) e [4, 8] e indique as alturas em texto.

Saída esperada

```text
[2.0, 4.0, 6.0]
[2, 3]
```
