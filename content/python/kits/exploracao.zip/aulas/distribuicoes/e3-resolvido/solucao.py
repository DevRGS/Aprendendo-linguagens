import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

def resumo(tempos):
    q1, mediana, q3 = np.quantile(tempos, [0.25, 0.5, 0.75], method="linear")
    return mediana, q3 - q1

tempos = [1, 2, 2, 3, 9]
mediana, aiq = resumo(tempos)
print(f"Mediana: {mediana:.1f} min. AIQ: {aiq:.1f} min.")
fig, ax = plt.subplots(layout="constrained")
contagens, _, _ = ax.hist(tempos, bins=[0, 3, 6, 9], edgecolor="black")
ax.set(xlabel="Tempo (min)", ylabel="Viagens (contagem)", title="Tempos observados")
fig.savefig("distribuicao.png")
plt.close(fig)
print("Contagens:", contagens.astype(int).tolist())
assert resumo([2, 2])[1] == 0
