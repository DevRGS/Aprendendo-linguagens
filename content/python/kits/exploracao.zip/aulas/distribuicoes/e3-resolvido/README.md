# Solução comentada

A amplitude entre Q1=2 e Q3=3 é 1 min. As barras mostram três viagens abaixo de 3 min, uma de 3 até menos de 6 e outra de 6 a 9. A amostra constante tem quartis iguais. A seguir estudaremos duas medidas de cada viagem.

Saída esperada

```text
Mediana: 2.0 min. AIQ: 1.0 min.
Contagens: [3, 1, 1]
```
